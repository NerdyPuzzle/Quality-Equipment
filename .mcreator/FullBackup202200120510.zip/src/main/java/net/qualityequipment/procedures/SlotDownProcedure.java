package net.qualityequipment.procedures;

import net.qualityequipment.QualityEquipmentModVariables;
import net.qualityequipment.QualityEquipmentMod;

import net.minecraft.entity.Entity;

import java.util.Map;

public class SlotDownProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure SlotDown!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		{
			double _setval = 1;
			entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.update2 = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}
