package net.qualityequipment.procedures;

import net.qualityequipment.entity.HitboxreachEntity;
import net.qualityequipment.QualityEquipmentMod;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.HoeItem;
import net.minecraft.item.AxeItem;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import java.util.function.Function;
import java.util.Map;
import java.util.HashMap;
import java.util.Comparator;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class DamageProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onEntityAttacked(LivingAttackEvent event) {
			if (event != null && event.getEntity() != null) {
				Entity entity = event.getEntity();
				Entity sourceentity = event.getSource().getTrueSource();
				Entity immediatesourceentity = event.getSource().getImmediateSource();
				double i = entity.getPosX();
				double j = entity.getPosY();
				double k = entity.getPosZ();
				double amount = event.getAmount();
				World world = entity.world;
				Map<String, Object> dependencies = new HashMap<>();
				dependencies.put("x", i);
				dependencies.put("y", j);
				dependencies.put("z", k);
				dependencies.put("amount", amount);
				dependencies.put("world", world);
				dependencies.put("entity", entity);
				dependencies.put("sourceentity", sourceentity);
				dependencies.put("immediatesourceentity", immediatesourceentity);
				dependencies.put("event", event);
				executeProcedure(dependencies);
			}
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency world for procedure Damage!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure Damage!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency sourceentity for procedure Damage!");
			return;
		}
		if (dependencies.get("amount") == null) {
			if (!dependencies.containsKey("amount"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency amount for procedure Damage!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		Entity entity = (Entity) dependencies.get("entity");
		Entity sourceentity = (Entity) dependencies.get("sourceentity");
		double amount = dependencies.get("amount") instanceof Integer ? (int) dependencies.get("amount") : (double) dependencies.get("amount");
		File stats = new File("");
		com.google.gson.JsonObject statsjsonobject = new com.google.gson.JsonObject();
		double damageoflegendary = 0;
		if (((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY)
				.getItem() instanceof SwordItem
				|| ((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getItem() instanceof PickaxeItem
				|| ((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getItem() instanceof AxeItem
				|| ((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getItem() instanceof ShovelItem
				|| ((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getItem() instanceof HoeItem) {
			stats = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgestats.json");
			{
				try {
					BufferedReader bufferedReader = new BufferedReader(new FileReader(stats));
					StringBuilder jsonstringbuilder = new StringBuilder();
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						jsonstringbuilder.append(line);
					}
					bufferedReader.close();
					statsjsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
					damageoflegendary = statsjsonobject.get("Legendary Positive Attack Damage Stat").getAsDouble();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (entity instanceof HitboxreachEntity.CustomEntity) {
				if (((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY).getOrCreateTag()
						.getBoolean("Long") == true) {
					((Entity) world
							.getEntitiesWithinAABB(LivingEntity.class,
									new AxisAlignedBB(
											(sourceentity.world
													.rayTraceBlocks(
															new RayTraceContext(sourceentity.getEyePosition(1f),
																	sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																			sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
																	RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getX()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getY()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getZ()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getX()) + (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getY()) + (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getZ()) + (15 / 2d)),
									null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getX()),
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getY()),
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getZ())))
							.findFirst().orElse(null)).attackEntityFrom(DamageSource.GENERIC, (float) (amount));
				} else if (((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Sweeping") == true) {
					((Entity) world
							.getEntitiesWithinAABB(LivingEntity.class,
									new AxisAlignedBB(
											(sourceentity.world
													.rayTraceBlocks(
															new RayTraceContext(sourceentity.getEyePosition(1f),
																	sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																			sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
																	RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getX()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getY()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getZ()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getX()) + (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getY()) + (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getZ()) + (15 / 2d)),
									null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getX()),
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getY()),
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getZ())))
							.findFirst().orElse(null)).attackEntityFrom(DamageSource.GENERIC, (float) (amount));
				} else if (((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Legendary") == true) {
					((Entity) world
							.getEntitiesWithinAABB(LivingEntity.class,
									new AxisAlignedBB(
											(sourceentity.world
													.rayTraceBlocks(
															new RayTraceContext(sourceentity.getEyePosition(1f),
																	sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																			sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
																	RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getX()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getY()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getZ()) - (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getX()) + (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getY()) + (15 / 2d),
											(sourceentity.world
													.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
															sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
																	sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
															RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
													.getPos().getZ()) + (15 / 2d)),
									null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getX()),
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getY()),
									(sourceentity.world
											.rayTraceBlocks(new RayTraceContext(sourceentity.getEyePosition(1f),
													sourceentity.getEyePosition(1f).add(sourceentity.getLook(1f).x * 3.5,
															sourceentity.getLook(1f).y * 3.5, sourceentity.getLook(1f).z * 3.5),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, sourceentity))
											.getPos().getZ())))
							.findFirst().orElse(null)).attackEntityFrom(DamageSource.GENERIC, (float) (amount + amount * damageoflegendary));
				}
			}
		}
	}
}
