package net.qualityequipment.procedures;

import net.qualityequipment.QualityEquipmentMod;

import net.minecraft.entity.Entity;

import java.util.Map;

public class HitboxreachEntityDiesProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure HitboxreachEntityDies!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (!entity.world.isRemote())
			entity.remove();
	}
}
