package net.qualityequipment.procedures;

import net.qualityequipment.QualityEquipmentModVariables;
import net.qualityequipment.QualityEquipmentMod;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.HoeItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ArmorItem;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.CommandSource;

import java.util.function.Function;
import java.util.Map;
import java.util.HashMap;
import java.util.Comparator;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class ReforgewhenpickupProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onGemDropped(ItemTossEvent event) {
			PlayerEntity entity = event.getPlayer();
			double i = entity.getPosX();
			double j = entity.getPosY();
			double k = entity.getPosZ();
			World world = entity.world;
			ItemStack itemstack = event.getEntityItem().getItem();
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("x", i);
			dependencies.put("y", j);
			dependencies.put("z", k);
			dependencies.put("world", world);
			dependencies.put("entity", entity);
			dependencies.put("itemstack", itemstack);
			dependencies.put("event", event);
			executeProcedure(dependencies);
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency world for procedure Reforgewhenpickup!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency x for procedure Reforgewhenpickup!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency y for procedure Reforgewhenpickup!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency z for procedure Reforgewhenpickup!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure Reforgewhenpickup!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency itemstack for procedure Reforgewhenpickup!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		String material = "";
		double Worthless = 0;
		double Broken = 0;
		double Chipped = 0;
		double Bulky = 0;
		double Rusted = 0;
		double Clumsy = 0;
		double Shorter = 0;
		double Pokey = 0;
		double Broad = 0;
		double Thin = 0;
		double Vicious = 0;
		double Longer = 0;
		double Sharp = 0;
		double Keen = 0;
		double Graceful = 0;
		double Sweeping = 0;
		double Legendary = 0;
		double ClumsyBow = 0;
		double Cracked = 0;
		double Light = 0;
		double Powerful = 0;
		double LegendaryBow = 0;
		double Crumbling = 0;
		double Dented = 0;
		double Heavy = 0;
		double Thick = 0;
		double Lucky = 0;
		double Springy = 0;
		double Speedy = 0;
		double Tough = 0;
		double Protective = 0;
		double Solid = 0;
		double Masterful = 0;
		double HeavyShield = 0;
		double ThickShield = 0;
		double SolidShield = 0;
		File qualityequipment = new File("");
		File chance = new File("");
		File stats = new File("");
		File crafted = new File("");
		com.google.gson.JsonObject mainjsonobject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject chancejsonobject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject statsjsonobject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject craftedjsonobject = new com.google.gson.JsonObject();
		boolean repeat = false;
		boolean enablereforgepickup = false;
		crafted = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgeonpickup.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(crafted));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				craftedjsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				enablereforgepickup = craftedjsonobject.get("Reforge on item pickup").getAsBoolean();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (enablereforgepickup == true) {
			chance = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgechance.json");
			stats = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgestats.json");
			{
				try {
					BufferedReader bufferedReader = new BufferedReader(new FileReader(chance));
					StringBuilder jsonstringbuilder = new StringBuilder();
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						jsonstringbuilder.append(line);
					}
					bufferedReader.close();
					chancejsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
					Worthless = chancejsonobject.get("Worthless").getAsDouble();
					Broken = chancejsonobject.get("Broken").getAsDouble();
					Chipped = chancejsonobject.get("Chipped").getAsDouble();
					Bulky = chancejsonobject.get("Bulky").getAsDouble();
					Rusted = chancejsonobject.get("Rusted").getAsDouble();
					Clumsy = chancejsonobject.get("Clumsy").getAsDouble();
					Pokey = chancejsonobject.get("Pokey").getAsDouble();
					Shorter = chancejsonobject.get("Short").getAsDouble();
					Broad = chancejsonobject.get("Broad").getAsDouble();
					Thin = chancejsonobject.get("Thin").getAsDouble();
					Vicious = chancejsonobject.get("Vicious").getAsDouble();
					Longer = chancejsonobject.get("Long").getAsDouble();
					Sharp = chancejsonobject.get("Sharp").getAsDouble();
					Keen = chancejsonobject.get("Keen").getAsDouble();
					Graceful = chancejsonobject.get("Graceful").getAsDouble();
					Sweeping = chancejsonobject.get("Sweeping").getAsDouble();
					Legendary = chancejsonobject.get("Legendary").getAsDouble();
					ClumsyBow = chancejsonobject.get("Clumsy Bow").getAsDouble();
					Cracked = chancejsonobject.get("Cracked").getAsDouble();
					Light = chancejsonobject.get("Light").getAsDouble();
					Powerful = chancejsonobject.get("Powerful").getAsDouble();
					LegendaryBow = chancejsonobject.get("Legendary Bow").getAsDouble();
					Crumbling = chancejsonobject.get("Crumbling").getAsDouble();
					Dented = chancejsonobject.get("Dented").getAsDouble();
					Heavy = chancejsonobject.get("Heavy").getAsDouble();
					Thick = chancejsonobject.get("Thick").getAsDouble();
					Lucky = chancejsonobject.get("Lucky").getAsDouble();
					Springy = chancejsonobject.get("Springy").getAsDouble();
					Speedy = chancejsonobject.get("Speedy").getAsDouble();
					Tough = chancejsonobject.get("Tough").getAsDouble();
					Protective = chancejsonobject.get("Protective").getAsDouble();
					Solid = chancejsonobject.get("Solid").getAsDouble();
					Masterful = chancejsonobject.get("Masterful").getAsDouble();
					HeavyShield = chancejsonobject.get("Heavy Shield").getAsDouble();
					ThickShield = chancejsonobject.get("Thick Shield").getAsDouble();
					SolidShield = chancejsonobject.get("Solid Shield").getAsDouble();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			{
				try {
					BufferedReader bufferedReader = new BufferedReader(new FileReader(stats));
					StringBuilder jsonstringbuilder = new StringBuilder();
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						jsonstringbuilder.append(line);
					}
					bufferedReader.close();
					statsjsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
					if (((Entity) world
							.getEntitiesWithinAABB(PlayerEntity.class,
									new AxisAlignedBB(x - (2 / 2d), y - (2 / 2d), z - (2 / 2d), x + (2 / 2d), y + (2 / 2d), z + (2 / 2d)), null)
							.stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)) != null
							&& !(itemstack.getOrCreateTag().getBoolean("Reforged") == true)) {
						itemstack.getOrCreateTag().putBoolean("Reforged", (true));
						if (itemstack.getItem() instanceof SwordItem || itemstack.getItem() instanceof PickaxeItem
								|| itemstack.getItem() instanceof AxeItem || itemstack.getItem() instanceof ShovelItem
								|| itemstack.getItem() instanceof HoeItem) {
							repeat = (true);
							while (repeat == true) {
								if (Math.random() <= Worthless) {
									itemstack.getOrCreateTag().putBoolean("Worthless", (true));
									{
										String _setval = statsjsonobject.get("Worthless Name").getAsString();
										entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
											capability.worthlessname = _setval;
											capability.syncPlayerVariables(entity);
										});
									}
									{
										String _setval = statsjsonobject.get("Worthless Negative Attack Speed Display").getAsString();
										entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
											capability.worthlessstat1 = _setval;
											capability.syncPlayerVariables(entity);
										});
									}
									QualityEquipmentModVariables.MapVariables.get(world).worthlessstat2 = statsjsonobject
											.get("Worthless Negative Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A74"
																+ ""
																+ (entity
																		.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																		.orElse(new QualityEquipmentModVariables.PlayerVariables())).worthlessname
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-10% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ (entity
																		.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																		.orElse(new QualityEquipmentModVariables.PlayerVariables())).worthlessstat1
																+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).worthlessstat2
																+ " Attack Damage\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-1 Reach Distance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Broken) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Broken Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Broken Negative Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Broken", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A78"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Chipped) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Chipped Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Chipped Negative Attack Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject
											.get("Chipped Negative Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Chipped", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Bulky) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Bulky Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Bulky Negative Attack Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Bulky", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A78"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-15% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Speed\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Rusted) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Rusted Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Rusted Negative Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Rusted", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-10% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Pokey) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Pokey Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Pokey Positive Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Pokey", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-10% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Clumsy) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Clumsy Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Clumsy Negative Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Clumsy", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-5% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Shorter) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Short Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Short", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-1 Reach Distance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Broad) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Broad Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Broad Negative Attack Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject
											.get("Broad Positive Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Broad", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-5% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Thin) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Thin Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Thin Positive Attack Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject
											.get("Thin Negative Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Thin", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Vicious) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Vicious Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Vicious Positive Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Vicious", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Damage\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-0.5 Reach Distance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Longer) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Long Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Long", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+0.5 Reach Distance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Sharp) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Sharp Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Sharp Positive Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Sharp", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Keen) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Keen Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Keen Positive Attack Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject
											.get("Keen Positive Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Keen", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Attack Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Graceful) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Graceful Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Graceful Positive Attack Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Graceful", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7b"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+15% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Speed\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Sweeping) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Sweeping Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Sweeping Positive Attack Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Sweeping", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7b"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+0.5 Reach Distance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Legendary) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Legendary Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Legendary Positive Attack Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject
											.get("Legendary Positive Attack Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Legendary", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7d"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+10% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Attack Damage\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+0.5 Reach Distance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else {
									repeat = (true);
								}
							}
						}
						if (itemstack.getItem() instanceof BowItem || itemstack.getItem() instanceof CrossbowItem) {
							repeat = (true);
							while (repeat == true) {
								if (Math.random() <= ClumsyBow) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Clumsy Bow Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Clumsy Bow Negative Projectile Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Clumsy Bow", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Projectile Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Cracked) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Cracked Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Cracked Negative Projectile Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Cracked", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A78"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Projectile Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Light) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Light Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Light Positive Projectile Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Light", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Projectile Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Powerful) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Powerful Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Powerful Positive Projectile Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Powerful", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7b"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Projectile Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= LegendaryBow) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Legendary Bow Name")
											.getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Legendary Bow Positive Projectile Damage Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Legendary Bow", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7d"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Projectile Damage\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else {
									repeat = (true);
								}
							}
						}
						if (itemstack.getItem() instanceof ArmorItem) {
							repeat = (true);
							while (repeat == true) {
								if (Math.random() <= Crumbling) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Crumbling Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Crumbling Negative Armor Toughness Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject
											.get("Crumbling Negative Armor Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Crumbling", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Armor Toughness\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Armor\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Dented) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Dented Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject.get("Dented Negative Armor Display")
											.getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Dented", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A78"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Armor\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Heavy) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Heavy Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject.get("Heavy Negative Speed Display")
											.getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Heavy", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Speed\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Thick) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Thick Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject.get("Thick Negative Speed Display")
											.getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject.get("Thick Positive Armor Display")
											.getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Thick", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Armor\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Lucky) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Lucky Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject.get("Lucky Positive Luck Display")
											.getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Lucky", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7b"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Luck\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Springy) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Springy Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Springy", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+0.5 Jump Height\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Speedy) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Speedy Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject.get("Speedy Positive Speed Display")
											.getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Speedy", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Speed\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Tough) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Tough Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Tough Positive Armor Toughness Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Tough", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Armor Toughness\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Protective) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Protective Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Protective Positive Armor Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Protective", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Armor\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Solid) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Solid Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Solid Positive Knockback Resistance Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Solid", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Knockback Resistance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= Masterful) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Masterful Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Masterful Positive Armor Toughness Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject
											.get("Masterful Positive Armor Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).four = statsjsonobject
											.get("Masterful Positive Knockback Resistance Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Masterful", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7d"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Armor Toughness\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Armor\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).four
																+ " Knockback Resistance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else {
									repeat = (true);
								}
							}
						}
						if (itemstack.getItem() instanceof ShieldItem) {
							repeat = (true);
							while (repeat == true) {
								if (Math.random() <= HeavyShield) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Heavy Shield Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Heavy Shield Negative Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Heavy Shield", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Speed\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= ThickShield) {
									itemstack.getOrCreateTag().putBoolean("Thick Shield", (true));
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Thick Shield Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Thick Shield Negative Speed Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).three = statsjsonobject
											.get("Thick Shield Positive Armor Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Speed\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).three
																+ " Armor\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else if (Math.random() <= SolidShield) {
									QualityEquipmentModVariables.MapVariables.get(world).one = statsjsonobject.get("Solid Shield Name").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									QualityEquipmentModVariables.MapVariables.get(world).two = statsjsonobject
											.get("Solid Shield Positive Knockback Resistance Display").getAsString();
									QualityEquipmentModVariables.MapVariables.get(world).syncData(world);
									itemstack.getOrCreateTag().putBoolean("Solid Shield", (true));
									new Object() {
										private int ticks = 0;
										private float waitTicks;
										private IWorld world;

										public void start(IWorld world, int waitTicks) {
											this.waitTicks = waitTicks;
											MinecraftForge.EVENT_BUS.register(this);
											this.world = world;
										}

										@SubscribeEvent
										public void tick(TickEvent.ServerTickEvent event) {
											if (event.phase == TickEvent.Phase.END) {
												this.ticks += 1;
												if (this.ticks >= this.waitTicks)
													run();
											}
										}

										private void run() {
											if (world instanceof ServerWorld) {
												((World) world).getServer().getCommandManager().handleCommand(
														new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO,
																(ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(),
																null).withFeedbackDisabled(),
														("data modify entity @e[type=minecraft:item,limit=1,sort=nearest,distance=..5] Item.tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
																+ "" + QualityEquipmentModVariables.MapVariables.get(world).one
																+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
																+ QualityEquipmentModVariables.MapVariables.get(world).two
																+ " Knockback Resistance\",\"italic\":false}]']}"));
											}
											MinecraftForge.EVENT_BUS.unregister(this);
										}
									}.start(world, (int) 1);
									repeat = (false);
								} else {
									repeat = (true);
								}
							}
						}
					}

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
