package net.qualityequipment.procedures;

import net.qualityequipment.QualityEquipmentModVariables;
import net.qualityequipment.QualityEquipmentMod;

import net.minecraft.entity.Entity;

import java.util.Map;

public class ShowoffhammerProcedure {

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure Showoffhammer!");
			return false;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new QualityEquipmentModVariables.PlayerVariables())).update1 == 1) {
			return true;
		}
		return false;
	}
}
