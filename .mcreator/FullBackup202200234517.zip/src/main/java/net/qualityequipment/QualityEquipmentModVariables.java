package net.qualityequipment;

import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.storage.WorldSavedData;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.world.IServerWorld;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Direction;
import net.minecraft.network.PacketBuffer;
import net.minecraft.nbt.INBT;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;

import java.util.function.Supplier;

public class QualityEquipmentModVariables {
	public QualityEquipmentModVariables(QualityEquipmentModElements elements) {
		elements.addNetworkMessage(WorldSavedDataSyncMessage.class, WorldSavedDataSyncMessage::buffer, WorldSavedDataSyncMessage::new,
				WorldSavedDataSyncMessage::handler);
		elements.addNetworkMessage(PlayerVariablesSyncMessage.class, PlayerVariablesSyncMessage::buffer, PlayerVariablesSyncMessage::new,
				PlayerVariablesSyncMessage::handler);
		FMLJavaModLoadingContext.get().getModEventBus().addListener(this::init);
	}

	private void init(FMLCommonSetupEvent event) {
		CapabilityManager.INSTANCE.register(PlayerVariables.class, new PlayerVariablesStorage(), PlayerVariables::new);
	}

	@SubscribeEvent
	public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		if (!event.getPlayer().world.isRemote()) {
			WorldSavedData mapdata = MapVariables.get(event.getPlayer().world);
			WorldSavedData worlddata = WorldVariables.get(event.getPlayer().world);
			if (mapdata != null)
				QualityEquipmentMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) event.getPlayer()),
						new WorldSavedDataSyncMessage(0, mapdata));
			if (worlddata != null)
				QualityEquipmentMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) event.getPlayer()),
						new WorldSavedDataSyncMessage(1, worlddata));
		}
	}

	@SubscribeEvent
	public void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
		if (!event.getPlayer().world.isRemote()) {
			WorldSavedData worlddata = WorldVariables.get(event.getPlayer().world);
			if (worlddata != null)
				QualityEquipmentMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) event.getPlayer()),
						new WorldSavedDataSyncMessage(1, worlddata));
		}
	}

	public static class WorldVariables extends WorldSavedData {
		public static final String DATA_NAME = "quality_equipment_worldvars";

		public WorldVariables() {
			super(DATA_NAME);
		}

		public WorldVariables(String s) {
			super(s);
		}

		@Override
		public void read(CompoundNBT nbt) {
		}

		@Override
		public CompoundNBT write(CompoundNBT nbt) {
			return nbt;
		}

		public void syncData(IWorld world) {
			this.markDirty();
			if (world instanceof World && !world.isRemote())
				QualityEquipmentMod.PACKET_HANDLER.send(PacketDistributor.DIMENSION.with(((World) world)::getDimensionKey),
						new WorldSavedDataSyncMessage(1, this));
		}

		static WorldVariables clientSide = new WorldVariables();

		public static WorldVariables get(IWorld world) {
			if (world instanceof ServerWorld) {
				return ((ServerWorld) world).getSavedData().getOrCreate(WorldVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends WorldSavedData {
		public static final String DATA_NAME = "quality_equipment_mapvars";
		public ItemStack y = ItemStack.EMPTY;
		public String worthlessstat2 = "\"\"";
		public String one = "\"\"";
		public String two = "\"\"";
		public String three = "\"\"";
		public String four = "\"\"";

		public MapVariables() {
			super(DATA_NAME);
		}

		public MapVariables(String s) {
			super(s);
		}

		@Override
		public void read(CompoundNBT nbt) {
			y = ItemStack.read(nbt.getCompound("y"));
			worthlessstat2 = nbt.getString("worthlessstat2");
			one = nbt.getString("one");
			two = nbt.getString("two");
			three = nbt.getString("three");
			four = nbt.getString("four");
		}

		@Override
		public CompoundNBT write(CompoundNBT nbt) {
			nbt.put("y", y.write(new CompoundNBT()));
			nbt.putString("worthlessstat2", worthlessstat2);
			nbt.putString("one", one);
			nbt.putString("two", two);
			nbt.putString("three", three);
			nbt.putString("four", four);
			return nbt;
		}

		public void syncData(IWorld world) {
			this.markDirty();
			if (world instanceof World && !world.isRemote())
				QualityEquipmentMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new WorldSavedDataSyncMessage(0, this));
		}

		static MapVariables clientSide = new MapVariables();

		public static MapVariables get(IWorld world) {
			if (world instanceof IServerWorld) {
				return ((IServerWorld) world).getWorld().getServer().getWorld(World.OVERWORLD).getSavedData().getOrCreate(MapVariables::new,
						DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class WorldSavedDataSyncMessage {
		public int type;
		public WorldSavedData data;

		public WorldSavedDataSyncMessage(PacketBuffer buffer) {
			this.type = buffer.readInt();
			this.data = this.type == 0 ? new MapVariables() : new WorldVariables();
			this.data.read(buffer.readCompoundTag());
		}

		public WorldSavedDataSyncMessage(int type, WorldSavedData data) {
			this.type = type;
			this.data = data;
		}

		public static void buffer(WorldSavedDataSyncMessage message, PacketBuffer buffer) {
			buffer.writeInt(message.type);
			buffer.writeCompoundTag(message.data.write(new CompoundNBT()));
		}

		public static void handler(WorldSavedDataSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					if (message.type == 0)
						MapVariables.clientSide = (MapVariables) message.data;
					else
						WorldVariables.clientSide = (WorldVariables) message.data;
				}
			});
			context.setPacketHandled(true);
		}
	}

	@CapabilityInject(PlayerVariables.class)
	public static Capability<PlayerVariables> PLAYER_VARIABLES_CAPABILITY = null;

	@SubscribeEvent
	public void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
		if (event.getObject() instanceof PlayerEntity && !(event.getObject() instanceof FakePlayer))
			event.addCapability(new ResourceLocation("quality_equipment", "player_variables"), new PlayerVariablesProvider());
	}

	private static class PlayerVariablesProvider implements ICapabilitySerializable<INBT> {
		private final LazyOptional<PlayerVariables> instance = LazyOptional.of(PLAYER_VARIABLES_CAPABILITY::getDefaultInstance);

		@Override
		public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
			return cap == PLAYER_VARIABLES_CAPABILITY ? instance.cast() : LazyOptional.empty();
		}

		@Override
		public INBT serializeNBT() {
			return PLAYER_VARIABLES_CAPABILITY.getStorage().writeNBT(PLAYER_VARIABLES_CAPABILITY, this.instance.orElseThrow(RuntimeException::new),
					null);
		}

		@Override
		public void deserializeNBT(INBT nbt) {
			PLAYER_VARIABLES_CAPABILITY.getStorage().readNBT(PLAYER_VARIABLES_CAPABILITY, this.instance.orElseThrow(RuntimeException::new), null,
					nbt);
		}
	}

	private static class PlayerVariablesStorage implements Capability.IStorage<PlayerVariables> {
		@Override
		public INBT writeNBT(Capability<PlayerVariables> capability, PlayerVariables instance, Direction side) {
			CompoundNBT nbt = new CompoundNBT();
			nbt.putDouble("sword", instance.sword);
			nbt.putDouble("ingot", instance.ingot);
			nbt.putDouble("update1", instance.update1);
			nbt.putDouble("update2", instance.update2);
			nbt.putBoolean("successhammer", instance.successhammer);
			nbt.putBoolean("successhammer2", instance.successhammer2);
			nbt.putDouble("attackattribute", instance.attackattribute);
			nbt.putBoolean("potiontrigger", instance.potiontrigger);
			nbt.putBoolean("attackspeed", instance.attackspeed);
			nbt.putDouble("amount", instance.amount);
			nbt.putBoolean("guireset", instance.guireset);
			nbt.putBoolean("guiopenagain", instance.guiopenagain);
			nbt.putBoolean("shieldchecker", instance.shieldchecker);
			nbt.putDouble("shieldspeedsave", instance.shieldspeedsave);
			nbt.putBoolean("shieldchecker2", instance.shieldchecker2);
			nbt.putBoolean("shieldchecker3", instance.shieldchecker3);
			nbt.putDouble("helmspeedsaver", instance.helmspeedsaver);
			nbt.putDouble("jumpheight", instance.jumpheight);
			nbt.putBoolean("springytrigger", instance.springytrigger);
			nbt.putDouble("chestspeedsaver", instance.chestspeedsaver);
			nbt.putDouble("legspeedsaver", instance.legspeedsaver);
			nbt.putDouble("bootspeedsaver", instance.bootspeedsaver);
			nbt.putDouble("invchecker", instance.invchecker);
			nbt.putBoolean("bowclumsy", instance.bowclumsy);
			nbt.putBoolean("held", instance.held);
			nbt.putBoolean("bowlight", instance.bowlight);
			nbt.putBoolean("bowcracked", instance.bowcracked);
			nbt.putBoolean("bowpowerful", instance.bowpowerful);
			nbt.putBoolean("bowlegendary", instance.bowlegendary);
			nbt.putString("worthlessname", instance.worthlessname);
			nbt.putString("worthlessstat1", instance.worthlessstat1);
			return nbt;
		}

		@Override
		public void readNBT(Capability<PlayerVariables> capability, PlayerVariables instance, Direction side, INBT inbt) {
			CompoundNBT nbt = (CompoundNBT) inbt;
			instance.sword = nbt.getDouble("sword");
			instance.ingot = nbt.getDouble("ingot");
			instance.update1 = nbt.getDouble("update1");
			instance.update2 = nbt.getDouble("update2");
			instance.successhammer = nbt.getBoolean("successhammer");
			instance.successhammer2 = nbt.getBoolean("successhammer2");
			instance.attackattribute = nbt.getDouble("attackattribute");
			instance.potiontrigger = nbt.getBoolean("potiontrigger");
			instance.attackspeed = nbt.getBoolean("attackspeed");
			instance.amount = nbt.getDouble("amount");
			instance.guireset = nbt.getBoolean("guireset");
			instance.guiopenagain = nbt.getBoolean("guiopenagain");
			instance.shieldchecker = nbt.getBoolean("shieldchecker");
			instance.shieldspeedsave = nbt.getDouble("shieldspeedsave");
			instance.shieldchecker2 = nbt.getBoolean("shieldchecker2");
			instance.shieldchecker3 = nbt.getBoolean("shieldchecker3");
			instance.helmspeedsaver = nbt.getDouble("helmspeedsaver");
			instance.jumpheight = nbt.getDouble("jumpheight");
			instance.springytrigger = nbt.getBoolean("springytrigger");
			instance.chestspeedsaver = nbt.getDouble("chestspeedsaver");
			instance.legspeedsaver = nbt.getDouble("legspeedsaver");
			instance.bootspeedsaver = nbt.getDouble("bootspeedsaver");
			instance.invchecker = nbt.getDouble("invchecker");
			instance.bowclumsy = nbt.getBoolean("bowclumsy");
			instance.held = nbt.getBoolean("held");
			instance.bowlight = nbt.getBoolean("bowlight");
			instance.bowcracked = nbt.getBoolean("bowcracked");
			instance.bowpowerful = nbt.getBoolean("bowpowerful");
			instance.bowlegendary = nbt.getBoolean("bowlegendary");
			instance.worthlessname = nbt.getString("worthlessname");
			instance.worthlessstat1 = nbt.getString("worthlessstat1");
		}
	}

	public static class PlayerVariables {
		public double sword = 0;
		public double ingot = 0;
		public double update1 = 0;
		public double update2 = 0;
		public boolean successhammer = false;
		public boolean successhammer2 = false;
		public double attackattribute = 0;
		public boolean potiontrigger = false;
		public boolean attackspeed = false;
		public double amount = 0;
		public boolean guireset = false;
		public boolean guiopenagain = false;
		public boolean shieldchecker = false;
		public double shieldspeedsave = 0;
		public boolean shieldchecker2 = false;
		public boolean shieldchecker3 = false;
		public double helmspeedsaver = 0;
		public double jumpheight = 0;
		public boolean springytrigger = false;
		public double chestspeedsaver = 0;
		public double legspeedsaver = 0;
		public double bootspeedsaver = 0;
		public double invchecker = 0;
		public boolean bowclumsy = false;
		public boolean held = false;
		public boolean bowlight = false;
		public boolean bowcracked = false;
		public boolean bowpowerful = false;
		public boolean bowlegendary = false;
		public String worthlessname = "\"\"";
		public String worthlessstat1 = "\"\"";

		public void syncPlayerVariables(Entity entity) {
			if (entity instanceof ServerPlayerEntity)
				QualityEquipmentMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) entity),
						new PlayerVariablesSyncMessage(this));
		}
	}

	@SubscribeEvent
	public void onPlayerLoggedInSyncPlayerVariables(PlayerEvent.PlayerLoggedInEvent event) {
		if (!event.getPlayer().world.isRemote())
			((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
					.syncPlayerVariables(event.getPlayer());
	}

	@SubscribeEvent
	public void onPlayerRespawnedSyncPlayerVariables(PlayerEvent.PlayerRespawnEvent event) {
		if (!event.getPlayer().world.isRemote())
			((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
					.syncPlayerVariables(event.getPlayer());
	}

	@SubscribeEvent
	public void onPlayerChangedDimensionSyncPlayerVariables(PlayerEvent.PlayerChangedDimensionEvent event) {
		if (!event.getPlayer().world.isRemote())
			((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
					.syncPlayerVariables(event.getPlayer());
	}

	@SubscribeEvent
	public void clonePlayer(PlayerEvent.Clone event) {
		PlayerVariables original = ((PlayerVariables) event.getOriginal().getCapability(PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new PlayerVariables()));
		PlayerVariables clone = ((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()));
		clone.sword = original.sword;
		clone.ingot = original.ingot;
		clone.update1 = original.update1;
		clone.update2 = original.update2;
		clone.successhammer = original.successhammer;
		clone.successhammer2 = original.successhammer2;
		clone.attackattribute = original.attackattribute;
		clone.potiontrigger = original.potiontrigger;
		clone.attackspeed = original.attackspeed;
		clone.amount = original.amount;
		clone.guireset = original.guireset;
		clone.guiopenagain = original.guiopenagain;
		clone.shieldchecker = original.shieldchecker;
		clone.shieldspeedsave = original.shieldspeedsave;
		clone.shieldchecker2 = original.shieldchecker2;
		clone.shieldchecker3 = original.shieldchecker3;
		clone.helmspeedsaver = original.helmspeedsaver;
		clone.jumpheight = original.jumpheight;
		clone.springytrigger = original.springytrigger;
		clone.chestspeedsaver = original.chestspeedsaver;
		clone.legspeedsaver = original.legspeedsaver;
		clone.bootspeedsaver = original.bootspeedsaver;
		clone.invchecker = original.invchecker;
		clone.bowclumsy = original.bowclumsy;
		clone.held = original.held;
		clone.bowlight = original.bowlight;
		clone.bowcracked = original.bowcracked;
		clone.bowpowerful = original.bowpowerful;
		clone.bowlegendary = original.bowlegendary;
		clone.worthlessname = original.worthlessname;
		clone.worthlessstat1 = original.worthlessstat1;
		if (!event.isWasDeath()) {
		}
	}

	public static class PlayerVariablesSyncMessage {
		public PlayerVariables data;

		public PlayerVariablesSyncMessage(PacketBuffer buffer) {
			this.data = new PlayerVariables();
			new PlayerVariablesStorage().readNBT(null, this.data, null, buffer.readCompoundTag());
		}

		public PlayerVariablesSyncMessage(PlayerVariables data) {
			this.data = data;
		}

		public static void buffer(PlayerVariablesSyncMessage message, PacketBuffer buffer) {
			buffer.writeCompoundTag((CompoundNBT) new PlayerVariablesStorage().writeNBT(null, message.data, null));
		}

		public static void handler(PlayerVariablesSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					PlayerVariables variables = ((PlayerVariables) Minecraft.getInstance().player.getCapability(PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new PlayerVariables()));
					variables.sword = message.data.sword;
					variables.ingot = message.data.ingot;
					variables.update1 = message.data.update1;
					variables.update2 = message.data.update2;
					variables.successhammer = message.data.successhammer;
					variables.successhammer2 = message.data.successhammer2;
					variables.attackattribute = message.data.attackattribute;
					variables.potiontrigger = message.data.potiontrigger;
					variables.attackspeed = message.data.attackspeed;
					variables.amount = message.data.amount;
					variables.guireset = message.data.guireset;
					variables.guiopenagain = message.data.guiopenagain;
					variables.shieldchecker = message.data.shieldchecker;
					variables.shieldspeedsave = message.data.shieldspeedsave;
					variables.shieldchecker2 = message.data.shieldchecker2;
					variables.shieldchecker3 = message.data.shieldchecker3;
					variables.helmspeedsaver = message.data.helmspeedsaver;
					variables.jumpheight = message.data.jumpheight;
					variables.springytrigger = message.data.springytrigger;
					variables.chestspeedsaver = message.data.chestspeedsaver;
					variables.legspeedsaver = message.data.legspeedsaver;
					variables.bootspeedsaver = message.data.bootspeedsaver;
					variables.invchecker = message.data.invchecker;
					variables.bowclumsy = message.data.bowclumsy;
					variables.held = message.data.held;
					variables.bowlight = message.data.bowlight;
					variables.bowcracked = message.data.bowcracked;
					variables.bowpowerful = message.data.bowpowerful;
					variables.bowlegendary = message.data.bowlegendary;
					variables.worthlessname = message.data.worthlessname;
					variables.worthlessstat1 = message.data.worthlessstat1;
				}
			});
			context.setPacketHandled(true);
		}
	}
}
