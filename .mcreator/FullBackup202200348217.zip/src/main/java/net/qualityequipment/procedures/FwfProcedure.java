package net.qualityequipment.procedures;

import net.qualityequipment.configuration.AConfiguration;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.util.ResourceLocation;

import java.util.Map;

public class FwfProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		ForgeRegistries.BLOCKS.getValue(new ResourceLocation(AConfiguration.A.get()));
	}
}
