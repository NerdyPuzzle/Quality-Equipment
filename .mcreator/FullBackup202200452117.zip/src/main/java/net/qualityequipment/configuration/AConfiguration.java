package net.qualityequipment.configuration;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.common.ForgeConfigSpec;

import net.minecraft.block.Blocks;

public class AConfiguration {
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.ConfigValue<String> A;
	static {
		BUILDER.push("a");
		A = BUILDER.comment("a").define("a", ForgeRegistries.ITEMS.getKey(Blocks.MOSSY_COBBLESTONE.asItem()).toString());
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
