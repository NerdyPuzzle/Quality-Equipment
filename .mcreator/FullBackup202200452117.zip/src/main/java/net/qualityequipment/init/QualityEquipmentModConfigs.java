package net.qualityequipment.init;

import net.qualityequipment.configuration.AConfiguration;

import net.minecraftforge.fml.event.lifecycle.FMLConstructModEvent;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@Mod.EventBusSubscriber(modid = "quality_equipment", bus = Mod.EventBusSubscriber.Bus.MOD)
public class QualityEquipmentModConfigs {
	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AConfiguration.SPEC, "a.toml");
		});
	}
}
