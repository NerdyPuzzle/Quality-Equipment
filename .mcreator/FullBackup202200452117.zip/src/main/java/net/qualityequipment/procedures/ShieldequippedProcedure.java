package net.qualityequipment.procedures;

import net.qualityequipment.QualityEquipmentModVariables;
import net.qualityequipment.QualityEquipmentMod;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.World;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.HashMap;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class ShieldequippedProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
			if (event.phase == TickEvent.Phase.END) {
				Entity entity = event.player;
				World world = entity.world;
				double i = entity.getPosX();
				double j = entity.getPosY();
				double k = entity.getPosZ();
				Map<String, Object> dependencies = new HashMap<>();
				dependencies.put("x", i);
				dependencies.put("y", j);
				dependencies.put("z", k);
				dependencies.put("world", world);
				dependencies.put("entity", entity);
				dependencies.put("event", event);
				executeProcedure(dependencies);
			}
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure Shieldequipped!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		File stats = new File("");
		com.google.gson.JsonObject statsjsonobject = new com.google.gson.JsonObject();
		stats = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgestats.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(stats));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				statsjsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)
						.getItem() instanceof ShieldItem) {
					if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY).getOrCreateTag()
							.getBoolean("Heavy Shield") == true) {
						if ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldchecker == false) {
							{
								boolean _setval = (true);
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.shieldchecker = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							{
								double _setval = (((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
										.getBaseValue() * statsjsonobject.get("Heavy Shield Negative Speed Stat").getAsDouble());
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.shieldspeedsave = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
									(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
											- (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldspeedsave));
						}
					}
				} else {
					if ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldchecker == true) {
						{
							boolean _setval = (false);
							entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.shieldchecker = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
										+ (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldspeedsave));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)
						.getItem() instanceof ShieldItem) {
					if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY).getOrCreateTag()
							.getBoolean("Thick Shield") == true) {
						if ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldchecker2 == false) {
							{
								boolean _setval = (true);
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.shieldchecker2 = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							{
								double _setval = (((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
										.getBaseValue() * statsjsonobject.get("Thick Shield Negative Speed Stat").getAsDouble());
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.shieldspeedsave = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
									(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
											- (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldspeedsave));
							((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
									(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
											+ statsjsonobject.get("Thick Shield Positive Armor Stat").getAsDouble()));
						}
					}
				} else {
					if ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldchecker2 == true) {
						{
							boolean _setval = (false);
							entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.shieldchecker2 = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
										+ (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldspeedsave));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										- statsjsonobject.get("Thick Shield Positive Armor Stat").getAsDouble()));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)
						.getItem() instanceof ShieldItem) {
					if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY).getOrCreateTag()
							.getBoolean("Solid Shield") == true) {
						if ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldchecker3 == false) {
							{
								boolean _setval = (true);
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.shieldchecker3 = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
									.setBaseValue((((LivingEntity) entity)
											.getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE).getBaseValue()
											+ statsjsonobject.get("Solid Shield Positive Knockback Resistance Stat").getAsDouble()));
						}
					}
				} else {
					if ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new QualityEquipmentModVariables.PlayerVariables())).shieldchecker3 == true) {
						{
							boolean _setval = (false);
							entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.shieldchecker3 = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
								.setBaseValue((((LivingEntity) entity)
										.getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE).getBaseValue()
										- statsjsonobject.get("Solid Shield Positive Knockback Resistance Stat").getAsDouble()));
					}
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
