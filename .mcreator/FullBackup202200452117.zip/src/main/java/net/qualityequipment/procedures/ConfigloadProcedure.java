package net.qualityequipment.procedures;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Map;
import java.util.Collections;

import java.io.IOException;
import java.io.FileWriter;
import java.io.File;

import com.google.gson.GsonBuilder;
import com.google.gson.Gson;

public class ConfigloadProcedure {
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void init(FMLCommonSetupEvent event) {
			executeProcedure(Collections.emptyMap());
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		File qualityequipment = new File("");
		File crafted = new File("");
		File chance = new File("");
		File stats = new File("");
		com.google.gson.JsonObject mainjsonobject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject craftedjsonobject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject chancejsonobject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject statsjsonobject = new com.google.gson.JsonObject();
		qualityequipment = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"),
				File.separator + "reforgematerials.json");
		stats = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgestats.json");
		crafted = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgeonpickup.json");
		chance = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgechance.json");
		if (!qualityequipment.exists()) {
			try {
				qualityequipment.getParentFile().mkdirs();
				qualityequipment.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			mainjsonobject.addProperty("Material for unspecified items", "iron_ingot");
			mainjsonobject.addProperty("turtle_helmet", "scute");
			mainjsonobject.addProperty("bow", "string");
			mainjsonobject.addProperty("wooden_sword", "oak_planks");
			mainjsonobject.addProperty("stone_sword", "cobblestone");
			mainjsonobject.addProperty("golden_sword", "gold_ingot");
			mainjsonobject.addProperty("iron_sword", "iron_ingot");
			mainjsonobject.addProperty("diamond_sword", "diamond");
			mainjsonobject.addProperty("netherite_sword", "netherite_scrap");
			mainjsonobject.addProperty("wooden_shovel", "oak_planks");
			mainjsonobject.addProperty("wooden_pickaxe", "oak_planks");
			mainjsonobject.addProperty("wooden_axe", "oak_planks");
			mainjsonobject.addProperty("wooden_hoe", "oak_planks");
			mainjsonobject.addProperty("stone_shovel", "cobblestone");
			mainjsonobject.addProperty("stone_pickaxe", "cobblestone");
			mainjsonobject.addProperty("stone_axe", "cobblestone");
			mainjsonobject.addProperty("stone_hoe", "cobblestone");
			mainjsonobject.addProperty("golden_shovel", "gold_ingot");
			mainjsonobject.addProperty("golden_pickaxe", "gold_ingot");
			mainjsonobject.addProperty("golden_axe", "gold_ingot");
			mainjsonobject.addProperty("golden_hoe", "gold_ingot");
			mainjsonobject.addProperty("iron_shovel", "iron_ingot");
			mainjsonobject.addProperty("iron_pickaxe", "iron_ingot");
			mainjsonobject.addProperty("iron_axe", "iron_ingot");
			mainjsonobject.addProperty("iron_hoe", "iron_ingot");
			mainjsonobject.addProperty("diamond_shovel", "diamond");
			mainjsonobject.addProperty("diamond_pickaxe", "diamond");
			mainjsonobject.addProperty("diamond_axe", "diamond");
			mainjsonobject.addProperty("diamond_hoe", "diamond");
			mainjsonobject.addProperty("netherite_shovel", "netherite_scrap");
			mainjsonobject.addProperty("netherite_pickaxe", "netherite_scrap");
			mainjsonobject.addProperty("netherite_axe", "netherite_scrap");
			mainjsonobject.addProperty("netherite_hoe", "netherite_scrap");
			mainjsonobject.addProperty("leather_helmet", "leather");
			mainjsonobject.addProperty("leather_chestplate", "leather");
			mainjsonobject.addProperty("leather_leggings", "leather");
			mainjsonobject.addProperty("leather_boots", "leather");
			mainjsonobject.addProperty("chainmail_helmet", "iron_bars");
			mainjsonobject.addProperty("chainmail_chestplate", "iron_bars");
			mainjsonobject.addProperty("chainmail_leggings", "iron_bars");
			mainjsonobject.addProperty("chainmail_boots", "iron_bars");
			mainjsonobject.addProperty("iron_helmet", "iron_ingot");
			mainjsonobject.addProperty("iron_chestplate", "iron_ingot");
			mainjsonobject.addProperty("iron_leggings", "iron_ingot");
			mainjsonobject.addProperty("iron_boots", "iron_ingot");
			mainjsonobject.addProperty("diamond_helmet", "diamond");
			mainjsonobject.addProperty("diamond_chestplate", "diamond");
			mainjsonobject.addProperty("diamond_leggings", "diamond");
			mainjsonobject.addProperty("diamond_boots", "diamond");
			mainjsonobject.addProperty("golden_helmet", "gold_ingot");
			mainjsonobject.addProperty("golden_chestplate", "gold_ingot");
			mainjsonobject.addProperty("golden_leggings", "gold_ingot");
			mainjsonobject.addProperty("golden_boots", "gold_ingot");
			mainjsonobject.addProperty("netherite_helmet", "netherite_scrap");
			mainjsonobject.addProperty("netherite_chestplate", "netherite_scrap");
			mainjsonobject.addProperty("netherite_leggings", "netherite_scrap");
			mainjsonobject.addProperty("netherite_boots", "netherite_scrap");
			mainjsonobject.addProperty("shield", "iron_ingot");
			mainjsonobject.addProperty("crossbow", "iron_ingot");
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(qualityequipment);
					fileWriter.write(mainGSONBuilderVariable.toJson(mainjsonobject));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
		if (!crafted.exists()) {
			try {
				crafted.getParentFile().mkdirs();
				crafted.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			craftedjsonobject.addProperty("Reforge on item pickup", (false));
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(crafted);
					fileWriter.write(mainGSONBuilderVariable.toJson(craftedjsonobject));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
		if (!chance.exists()) {
			try {
				chance.getParentFile().mkdirs();
				chance.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			chancejsonobject.addProperty("Chance to reforge can be set from 0 to 1", "");
			chancejsonobject.addProperty("Tool Reforges", "");
			chancejsonobject.addProperty("Worthless", 0.1);
			chancejsonobject.addProperty("Broken", 0.1);
			chancejsonobject.addProperty("Chipped", 0.1);
			chancejsonobject.addProperty("Bulky", 0.1);
			chancejsonobject.addProperty("Rusted", 0.1);
			chancejsonobject.addProperty("Clumsy", 0.1);
			chancejsonobject.addProperty("Short", 0.1);
			chancejsonobject.addProperty("Pokey", 0.12);
			chancejsonobject.addProperty("Broad", 0.15);
			chancejsonobject.addProperty("Thin", 0.15);
			chancejsonobject.addProperty("Vicious", 0.15);
			chancejsonobject.addProperty("Long", 0.15);
			chancejsonobject.addProperty("Sharp", 0.15);
			chancejsonobject.addProperty("Keen", 0.15);
			chancejsonobject.addProperty("Graceful", 0.15);
			chancejsonobject.addProperty("Sweeping", 0.15);
			chancejsonobject.addProperty("Legendary", 0.15);
			chancejsonobject.addProperty("Bow/Crossbow Reforges", "");
			chancejsonobject.addProperty("Clumsy Bow", 0.15);
			chancejsonobject.addProperty("Cracked", 0.15);
			chancejsonobject.addProperty("Light", 0.15);
			chancejsonobject.addProperty("Powerful", 0.15);
			chancejsonobject.addProperty("Legendary Bow", 0.1);
			chancejsonobject.addProperty("Armor Reforges", "");
			chancejsonobject.addProperty("Crumbling", 0.12);
			chancejsonobject.addProperty("Dented", 0.12);
			chancejsonobject.addProperty("Heavy", 0.12);
			chancejsonobject.addProperty("Thick", 0.12);
			chancejsonobject.addProperty("Lucky", 0.12);
			chancejsonobject.addProperty("Springy", 0.15);
			chancejsonobject.addProperty("Speedy", 0.15);
			chancejsonobject.addProperty("Tough", 0.15);
			chancejsonobject.addProperty("Protective", 0.15);
			chancejsonobject.addProperty("Solid", 0.15);
			chancejsonobject.addProperty("Masterful", 0.15);
			chancejsonobject.addProperty("Shield Reforges", "");
			chancejsonobject.addProperty("Heavy Shield", 0.15);
			chancejsonobject.addProperty("Thick Shield", 0.15);
			chancejsonobject.addProperty("Solid Shield", 0.15);
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(chance);
					fileWriter.write(mainGSONBuilderVariable.toJson(chancejsonobject));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
		if (!stats.exists()) {
			try {
				stats.getParentFile().mkdirs();
				stats.createNewFile();
			} catch (IOException exception) {
				exception.printStackTrace();
			}
			statsjsonobject.addProperty("Tool Reforge Stats", "");
			statsjsonobject.addProperty("Worthless Name", "Worthless");
			statsjsonobject.addProperty("Worthless Negative Attack Speed Display", "10%");
			statsjsonobject.addProperty("Worthless Negative Attack Speed Stat", 0.055);
			statsjsonobject.addProperty("Worthless Negative Attack Damage Display", "10%");
			statsjsonobject.addProperty("Worthless Negative Attack Damage Stat", 0.1);
			statsjsonobject.addProperty("Broken Name", "Broken");
			statsjsonobject.addProperty("Broken Negative Attack Damage Display", "15%");
			statsjsonobject.addProperty("Broken Negative Attack Damage Stat", 0.15);
			statsjsonobject.addProperty("Bulky Name", "Bulky");
			statsjsonobject.addProperty("Bulky Negative Attack Speed Display", "15%");
			statsjsonobject.addProperty("Bulky Negative Attack Speed Stat", 0.1);
			statsjsonobject.addProperty("Rusted Name", "Rusted");
			statsjsonobject.addProperty("Rusted Negative Attack Damage Display", "10%");
			statsjsonobject.addProperty("Rusted Negative Attack Damage Stat", 0.1);
			statsjsonobject.addProperty("Clumsy Name", "Clumsy");
			statsjsonobject.addProperty("Clumsy Negative Attack Damage Display", "5%");
			statsjsonobject.addProperty("Clumsy Negative Attack Damage Stat", 0.05);
			statsjsonobject.addProperty("Chipped Name", "Chipped");
			statsjsonobject.addProperty("Chipped Negative Attack Speed Display", "5%");
			statsjsonobject.addProperty("Chipped Negative Attack Speed Stat", 0.025);
			statsjsonobject.addProperty("Chipped Negative Attack Damage Display", "5%");
			statsjsonobject.addProperty("Chipped Negative Attack Damage Stat", 0.05);
			statsjsonobject.addProperty("Short Name", "Short");
			statsjsonobject.addProperty("Broad Name", "Broad");
			statsjsonobject.addProperty("Broad Negative Attack Speed Display", "5%");
			statsjsonobject.addProperty("Broad Negative Attack Speed Stat", 0.025);
			statsjsonobject.addProperty("Broad Positive Attack Damage Display", "10%");
			statsjsonobject.addProperty("Broad Positive Attack Damage Stat", 0.1);
			statsjsonobject.addProperty("Thin Name", "Thin");
			statsjsonobject.addProperty("Thin Positive Attack Speed Display", "10%");
			statsjsonobject.addProperty("Thin Positive Attack Speed Stat", 0.055);
			statsjsonobject.addProperty("Thin Negative Attack Damage Display", "5%");
			statsjsonobject.addProperty("Thin Negative Attack Damage Stat", 0.05);
			statsjsonobject.addProperty("Pokey Name", "Pokey");
			statsjsonobject.addProperty("Pokey Positive Attack Damage Display", "5%");
			statsjsonobject.addProperty("Pokey Positive Attack Damage Stat", 0.05);
			statsjsonobject.addProperty("Vicious Name", "Vicious");
			statsjsonobject.addProperty("Vicious Positive Attack Damage Display", "15%");
			statsjsonobject.addProperty("Vicious Positive Attack Damage Stat", 0.15);
			statsjsonobject.addProperty("Long Name", "Long");
			statsjsonobject.addProperty("Sharp Name", "Sharp");
			statsjsonobject.addProperty("Sharp Positive Attack Damage Display", "10%");
			statsjsonobject.addProperty("Sharp Positive Attack Damage Stat", 0.1);
			statsjsonobject.addProperty("Keen Name", "Keen");
			statsjsonobject.addProperty("Keen Positive Attack Speed Display", "10%");
			statsjsonobject.addProperty("Keen Positive Attack Speed Stat", 0.055);
			statsjsonobject.addProperty("Keen Positive Attack Damage Display", "10%");
			statsjsonobject.addProperty("Keen Positive Attack Damage Stat", 0.1);
			statsjsonobject.addProperty("Graceful Name", "Graceful");
			statsjsonobject.addProperty("Graceful Positive Attack Speed Display", "15%");
			statsjsonobject.addProperty("Graceful Positive Attack Speed Stat", 0.1);
			statsjsonobject.addProperty("Sweeping Name", "Sweeping");
			statsjsonobject.addProperty("Sweeping Positive Attack Speed Display", "20%");
			statsjsonobject.addProperty("Sweeping Positive Attack Speed Stat", 0.125);
			statsjsonobject.addProperty("Legendary Name", "Legendary");
			statsjsonobject.addProperty("Legendary Positive Attack Speed Display", "10%");
			statsjsonobject.addProperty("Legendary Positive Attack Speed Stat", 0.055);
			statsjsonobject.addProperty("Legendary Positive Attack Damage Display", "15%");
			statsjsonobject.addProperty("Legendary Positive Attack Damage Stat", 0.15);
			statsjsonobject.addProperty("Bow/Crossbow Reforge Stats", "");
			statsjsonobject.addProperty("Cracked Name", "Cracked");
			statsjsonobject.addProperty("Cracked Negative Projectile Damage Display", "15%");
			statsjsonobject.addProperty("Cracked Negative Projectile Damage Stat", 0.15);
			statsjsonobject.addProperty("Clumsy Bow Name", "Clumsy");
			statsjsonobject.addProperty("Clumsy Bow Negative Projectile Damage Display", "5%");
			statsjsonobject.addProperty("Clumsy Bow Negative Projectile Damage Stat", 0.05);
			statsjsonobject.addProperty("Light Name", "Light");
			statsjsonobject.addProperty("Light Positive Projectile Damage Display", "5%");
			statsjsonobject.addProperty("Light Positive Projectile Damage Stat", 0.05);
			statsjsonobject.addProperty("Powerful Name", "Powerful");
			statsjsonobject.addProperty("Powerful Positive Projectile Damage Display", "10%");
			statsjsonobject.addProperty("Powerful Positive Projectile Damage Stat", 0.1);
			statsjsonobject.addProperty("Legendary Bow Name", "Legendary");
			statsjsonobject.addProperty("Legendary Bow Positive Projectile Damage Display", "15%");
			statsjsonobject.addProperty("Legendary Bow Positive Projectile Damage Stat", 0.15);
			statsjsonobject.addProperty("Armor Reforge Stats", "");
			statsjsonobject.addProperty("Crumbling Name", "Crumbling");
			statsjsonobject.addProperty("Crumbling Negative Armor Toughness Display", "1");
			statsjsonobject.addProperty("Crumbling Negative Armor Toughness Stat", 1);
			statsjsonobject.addProperty("Crumbling Negative Armor Display", "1.5");
			statsjsonobject.addProperty("Crumbling Negative Armor Stat", 1.5);
			statsjsonobject.addProperty("Dented Name", "Dented");
			statsjsonobject.addProperty("Dented Negative Armor Display", "1");
			statsjsonobject.addProperty("Dented Negative Armor Stat", 1);
			statsjsonobject.addProperty("Heavy Name", "Heavy");
			statsjsonobject.addProperty("Heavy Negative Speed Display", "10%");
			statsjsonobject.addProperty("Heavy Negative Speed Stat", 0.1);
			statsjsonobject.addProperty("Thick Name", "Thick");
			statsjsonobject.addProperty("Thick Negative Speed Display", "5%");
			statsjsonobject.addProperty("Thick Negative Speed Stat", 0.05);
			statsjsonobject.addProperty("Thick Positive Armor Display", "1");
			statsjsonobject.addProperty("Thick Positive Armor Stat", 1);
			statsjsonobject.addProperty("Lucky Name", "Lucky");
			statsjsonobject.addProperty("Lucky Positive Luck Display", "0.5");
			statsjsonobject.addProperty("Lucky Positive Luck Stat", 0.5);
			statsjsonobject.addProperty("Springy Name", "Springy");
			statsjsonobject.addProperty("Speedy Name", "Speedy");
			statsjsonobject.addProperty("Speedy Positive Speed Display", "10%");
			statsjsonobject.addProperty("Speedy Positive Speed Stat", 0.1);
			statsjsonobject.addProperty("Tough Name", "Tough");
			statsjsonobject.addProperty("Tough Positive Armor Toughness Display", "1");
			statsjsonobject.addProperty("Tough Positive Armor Toughness Stat", 1);
			statsjsonobject.addProperty("Protective Name", "Protective");
			statsjsonobject.addProperty("Protective Positive Armor Display", "1");
			statsjsonobject.addProperty("Protective Positive Armor Stat", 1);
			statsjsonobject.addProperty("Solid Name", "Solid");
			statsjsonobject.addProperty("Solid Positive Knockback Resistance Display", "0.5");
			statsjsonobject.addProperty("Solid Positive Knockback Resistance Stat", 0.5);
			statsjsonobject.addProperty("Masterful Name", "Masterful");
			statsjsonobject.addProperty("Masterful Positive Armor Toughness Display", "1");
			statsjsonobject.addProperty("Masterful Positive Armor Toughness Stat", 1);
			statsjsonobject.addProperty("Masterful Positive Armor Display", "1");
			statsjsonobject.addProperty("Masterful Positive Armor Stat", 1);
			statsjsonobject.addProperty("Masterful Positive Knockback Resistance Display", "0.5");
			statsjsonobject.addProperty("Masterful Positive Knockback Resistance Stat", 0.5);
			statsjsonobject.addProperty("Shield Reforge Stats", "");
			statsjsonobject.addProperty("Heavy Shield Name", "Heavy");
			statsjsonobject.addProperty("Heavy Shield Negative Speed Display", "10%");
			statsjsonobject.addProperty("Heavy Shield Negative Speed Stat", 0.1);
			statsjsonobject.addProperty("Thick Shield Name", "Thick");
			statsjsonobject.addProperty("Thick Shield Negative Speed Display", "5%");
			statsjsonobject.addProperty("Thick Shield Negative Speed Stat", 0.05);
			statsjsonobject.addProperty("Thick Shield Positive Armor Display", "0.5");
			statsjsonobject.addProperty("Thick Shield Positive Armor Stat", 0.5);
			statsjsonobject.addProperty("Solid Shield Name", "Solid");
			statsjsonobject.addProperty("Solid Shield Positive Knockback Resistance Display", "0.5");
			statsjsonobject.addProperty("Solid Shield Positive Knockback Resistance Stat", 0.5);
			{
				Gson mainGSONBuilderVariable = new GsonBuilder().setPrettyPrinting().create();
				try {
					FileWriter fileWriter = new FileWriter(stats);
					fileWriter.write(mainGSONBuilderVariable.toJson(statsjsonobject));
					fileWriter.close();
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}
		}
	}
}
