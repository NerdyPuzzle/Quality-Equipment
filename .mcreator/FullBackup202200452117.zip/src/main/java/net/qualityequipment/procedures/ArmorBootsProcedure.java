package net.qualityequipment.procedures;

import net.qualityequipment.QualityEquipmentModVariables;
import net.qualityequipment.QualityEquipmentMod;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScoreCriteria;
import net.minecraft.item.ItemStack;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.HashMap;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class ArmorBootsProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
			if (event.phase == TickEvent.Phase.END) {
				Entity entity = event.player;
				World world = entity.world;
				double i = entity.getPosX();
				double j = entity.getPosY();
				double k = entity.getPosZ();
				Map<String, Object> dependencies = new HashMap<>();
				dependencies.put("x", i);
				dependencies.put("y", j);
				dependencies.put("z", k);
				dependencies.put("world", world);
				dependencies.put("entity", entity);
				dependencies.put("event", event);
				executeProcedure(dependencies);
			}
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure ArmorBoots!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		File stats = new File("");
		com.google.gson.JsonObject statsjsonobject = new com.google.gson.JsonObject();
		stats = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgestats.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(stats));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				statsjsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Solid") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot1", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot1");
							if (_so == null)
								_so = _sc.addObjective("boot1", ScoreCriteria.DUMMY, new StringTextComponent("boot1"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
										.getBaseValue() + statsjsonobject.get("Solid Positive Knockback Resistance Stat").getAsDouble()));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot1", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot1");
							if (_so == null)
								_so = _sc.addObjective("boot1", ScoreCriteria.DUMMY, new StringTextComponent("boot1"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
										.getBaseValue() - statsjsonobject.get("Solid Positive Knockback Resistance Stat").getAsDouble()));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Thick") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot2", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot2");
							if (_so == null)
								_so = _sc.addObjective("boot2", ScoreCriteria.DUMMY, new StringTextComponent("boot2"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						{
							double _setval = (((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
									.getBaseValue() * statsjsonobject.get("Thick Negative Speed Stat").getAsDouble());
							entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.bootspeedsaver = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										+ statsjsonobject.get("Thick Positive Armor Stat").getAsDouble()));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
										- (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new QualityEquipmentModVariables.PlayerVariables())).bootspeedsaver));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot2", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot2");
							if (_so == null)
								_so = _sc.addObjective("boot2", ScoreCriteria.DUMMY, new StringTextComponent("boot2"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										- statsjsonobject.get("Thick Positive Armor Stat").getAsDouble()));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
										+ (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new QualityEquipmentModVariables.PlayerVariables())).bootspeedsaver));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Protective") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot3", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot3");
							if (_so == null)
								_so = _sc.addObjective("boot3", ScoreCriteria.DUMMY, new StringTextComponent("boot3"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										+ statsjsonobject.get("Protective Positive Armor Stat").getAsDouble()));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot3", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot3");
							if (_so == null)
								_so = _sc.addObjective("boot3", ScoreCriteria.DUMMY, new StringTextComponent("boot3"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										- statsjsonobject.get("Protective Positive Armor Stat").getAsDouble()));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Crumbling") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot4", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot4");
							if (_so == null)
								_so = _sc.addObjective("boot4", ScoreCriteria.DUMMY, new StringTextComponent("boot4"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										- statsjsonobject.get("Crumbling Negative Armor Stat").getAsDouble()));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).getBaseValue()
										- statsjsonobject.get("Crumbling Negative Armor Toughness Stat").getAsDouble()));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot4", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot4");
							if (_so == null)
								_so = _sc.addObjective("boot4", ScoreCriteria.DUMMY, new StringTextComponent("boot4"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										+ statsjsonobject.get("Crumbling Negative Armor Stat").getAsDouble()));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).getBaseValue()
										+ statsjsonobject.get("Crumbling Negative Armor Toughness Stat").getAsDouble()));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Tough") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot5", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot5");
							if (_so == null)
								_so = _sc.addObjective("boot5", ScoreCriteria.DUMMY, new StringTextComponent("boot5"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).getBaseValue()
										+ statsjsonobject.get("Tough Positive Armor Toughness Stat").getAsDouble()));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot5", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot5");
							if (_so == null)
								_so = _sc.addObjective("boot5", ScoreCriteria.DUMMY, new StringTextComponent("boot5"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).getBaseValue()
										- statsjsonobject.get("Tough Positive Armor Toughness Stat").getAsDouble()));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Heavy") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot6", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot6");
							if (_so == null)
								_so = _sc.addObjective("boot6", ScoreCriteria.DUMMY, new StringTextComponent("boot6"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						{
							double _setval = (((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
									.getBaseValue() * statsjsonobject.get("Heavy Negative Speed Stat").getAsDouble());
							entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.bootspeedsaver = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
										- (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new QualityEquipmentModVariables.PlayerVariables())).bootspeedsaver));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot6", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot6");
							if (_so == null)
								_so = _sc.addObjective("boot6", ScoreCriteria.DUMMY, new StringTextComponent("boot6"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
										+ (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new QualityEquipmentModVariables.PlayerVariables())).bootspeedsaver));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Masterful") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot7", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot7");
							if (_so == null)
								_so = _sc.addObjective("boot7", ScoreCriteria.DUMMY, new StringTextComponent("boot7"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).getBaseValue()
										+ statsjsonobject.get("Masterful Positive Armor Toughness Stat").getAsDouble()));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										+ statsjsonobject.get("Masterful Positive Armor Stat").getAsDouble()));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
										.getBaseValue() + statsjsonobject.get("Masterful Positive Knockback Resistance Stat").getAsDouble()));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot7", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot7");
							if (_so == null)
								_so = _sc.addObjective("boot7", ScoreCriteria.DUMMY, new StringTextComponent("boot7"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR_TOUGHNESS).getBaseValue()
										- statsjsonobject.get("Masterful Positive Armor Toughness Stat").getAsDouble()));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										- statsjsonobject.get("Masterful Positive Armor Stat").getAsDouble()));
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
										.getBaseValue() - statsjsonobject.get("Masterful Positive Knockback Resistance Stat").getAsDouble()));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Dented") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot8", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot8");
							if (_so == null)
								_so = _sc.addObjective("boot8", ScoreCriteria.DUMMY, new StringTextComponent("boot8"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										- statsjsonobject.get("Dented Negative Armor Stat").getAsDouble()));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot8", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot8");
							if (_so == null)
								_so = _sc.addObjective("boot8", ScoreCriteria.DUMMY, new StringTextComponent("boot8"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.ARMOR).getBaseValue()
										+ statsjsonobject.get("Dented Negative Armor Stat").getAsDouble()));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Lucky") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot9", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot9");
							if (_so == null)
								_so = _sc.addObjective("boot9", ScoreCriteria.DUMMY, new StringTextComponent("boot9"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.LUCK)
								.setBaseValue((((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.LUCK).getBaseValue()
										+ statsjsonobject.get("Lucky Positive Luck Stat").getAsDouble()));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot9", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot9");
							if (_so == null)
								_so = _sc.addObjective("boot9", ScoreCriteria.DUMMY, new StringTextComponent("boot9"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.LUCK)
								.setBaseValue((((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.LUCK).getBaseValue()
										- statsjsonobject.get("Lucky Positive Luck Stat").getAsDouble()));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Speedy") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot10", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot10");
							if (_so == null)
								_so = _sc.addObjective("boot10", ScoreCriteria.DUMMY, new StringTextComponent("boot10"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						{
							double _setval = (((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
									.getBaseValue() * statsjsonobject.get("Speedy Positive Speed Stat").getAsDouble());
							entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.bootspeedsaver = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
										+ (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new QualityEquipmentModVariables.PlayerVariables())).bootspeedsaver));
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot10", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot10");
							if (_so == null)
								_so = _sc.addObjective("boot10", ScoreCriteria.DUMMY, new StringTextComponent("boot10"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).setBaseValue(
								(((LivingEntity) entity).getAttribute(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED).getBaseValue()
										- (entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new QualityEquipmentModVariables.PlayerVariables())).bootspeedsaver));
					}
				}
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET) : ItemStack.EMPTY)
						.getOrCreateTag().getBoolean("Springy") == true) {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot11", entity) < 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot11");
							if (_so == null)
								_so = _sc.addObjective("boot11", ScoreCriteria.DUMMY, new StringTextComponent("boot11"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
						}
						{
							double _setval = ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new QualityEquipmentModVariables.PlayerVariables())).jumpheight + 1);
							entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.jumpheight = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
					}
				} else {
					if (new Object() {
						public int getScore(String score, Entity _ent) {
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective(score);
							if (_so != null)
								return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
							return 0;
						}
					}.getScore("boot11", entity) == 1) {
						{
							Entity _ent = entity;
							Scoreboard _sc = _ent.world.getScoreboard();
							ScoreObjective _so = _sc.getObjective("boot11");
							if (_so == null)
								_so = _sc.addObjective("boot11", ScoreCriteria.DUMMY, new StringTextComponent("boot11"),
										ScoreCriteria.RenderType.INTEGER);
							_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 0);
						}
						{
							double _setval = ((entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new QualityEquipmentModVariables.PlayerVariables())).jumpheight - 1);
							entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.jumpheight = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
					}
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
