package net.qualityequipment.procedures;

import net.qualityequipment.QualityEquipmentModVariables;
import net.qualityequipment.QualityEquipmentMod;

import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.item.ShootableItem;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import java.util.function.Function;
import java.util.Map;
import java.util.HashMap;
import java.util.Comparator;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class ArrowmodifierProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onEntityAttacked(LivingAttackEvent event) {
			if (event != null && event.getEntity() != null) {
				Entity entity = event.getEntity();
				Entity sourceentity = event.getSource().getTrueSource();
				Entity immediatesourceentity = event.getSource().getImmediateSource();
				double i = entity.getPosX();
				double j = entity.getPosY();
				double k = entity.getPosZ();
				double amount = event.getAmount();
				World world = entity.world;
				Map<String, Object> dependencies = new HashMap<>();
				dependencies.put("x", i);
				dependencies.put("y", j);
				dependencies.put("z", k);
				dependencies.put("amount", amount);
				dependencies.put("world", world);
				dependencies.put("entity", entity);
				dependencies.put("sourceentity", sourceentity);
				dependencies.put("immediatesourceentity", immediatesourceentity);
				dependencies.put("event", event);
				executeProcedure(dependencies);
			}
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency world for procedure Arrowmodifier!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency x for procedure Arrowmodifier!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency y for procedure Arrowmodifier!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency z for procedure Arrowmodifier!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure Arrowmodifier!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency sourceentity for procedure Arrowmodifier!");
			return;
		}
		if (dependencies.get("amount") == null) {
			if (!dependencies.containsKey("amount"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency amount for procedure Arrowmodifier!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		Entity entity = (Entity) dependencies.get("entity");
		Entity sourceentity = (Entity) dependencies.get("sourceentity");
		double amount = dependencies.get("amount") instanceof Integer ? (int) dependencies.get("amount") : (double) dependencies.get("amount");
		File stats = new File("");
		com.google.gson.JsonObject statsjsonobject = new com.google.gson.JsonObject();
		stats = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgestats.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(stats));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				statsjsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				if (((Entity) world.getEntitiesWithinAABB(PlayerEntity.class,
						new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d), z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)), null)
						.stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)) != null && sourceentity instanceof PlayerEntity) {
					if (((((Entity) world.getEntitiesWithinAABB(PlayerEntity.class,
							new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d), z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)),
							null).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
								}
							}.compareDistOf(x, y,
									z))
							.findFirst().orElse(null)) instanceof LivingEntity)
									? ((LivingEntity) ((Entity) world
											.getEntitiesWithinAABB(PlayerEntity.class, new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d),
													z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)), null)
											.stream().sorted(new Object() {
												Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
													return Comparator
															.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
												}
											}.compareDistOf(x, y, z)).findFirst().orElse(null))).getHeldItemOffhand()
									: ItemStack.EMPTY)
							.getItem() instanceof ShootableItem
							|| ((((Entity) world.getEntitiesWithinAABB(PlayerEntity.class, new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d),
									z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)), null).stream().sorted(new Object() {
										Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
											return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
										}
									}.compareDistOf(x, y, z)).findFirst().orElse(
											null)) instanceof LivingEntity)
													? ((LivingEntity) ((Entity) world
															.getEntitiesWithinAABB(PlayerEntity.class,
																	new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d), z - (1000 / 2d),
																			x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)),
																	null)
															.stream().sorted(new Object() {
																Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
																	return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd
																			.getDistanceSq(_x, _y, _z)));
																}
															}.compareDistOf(x, y, z)).findFirst().orElse(null))).getHeldItemMainhand()
													: ItemStack.EMPTY)
									.getItem() instanceof ShootableItem) {
						if ((((Entity) world.getEntitiesWithinAABB(PlayerEntity.class, new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d),
								z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)), null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf(x, y, z)).findFirst().orElse(null))
								.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new QualityEquipmentModVariables.PlayerVariables())).bowclumsy == true) {
							if (entity instanceof LivingEntity)
								((LivingEntity) entity)
										.setHealth((float) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1)
												+ amount * statsjsonobject.get("Clumsy Bow Negative Projectile Damage Stat").getAsDouble()));
						} else if ((((Entity) world.getEntitiesWithinAABB(PlayerEntity.class, new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d),
								z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)), null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf(x, y, z)).findFirst().orElse(null))
								.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new QualityEquipmentModVariables.PlayerVariables())).bowlight == true) {
							if (entity instanceof LivingEntity)
								((LivingEntity) entity)
										.setHealth((float) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1)
												- amount * statsjsonobject.get("Light Positive Projectile Damage Stat").getAsDouble()));
						} else if ((((Entity) world.getEntitiesWithinAABB(PlayerEntity.class, new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d),
								z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)), null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf(x, y, z)).findFirst().orElse(null))
								.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new QualityEquipmentModVariables.PlayerVariables())).bowcracked == true) {
							if (entity instanceof LivingEntity)
								((LivingEntity) entity)
										.setHealth((float) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1)
												+ amount * statsjsonobject.get("Cracked Negative Projectile Damage Stat").getAsDouble()));
						} else if ((((Entity) world.getEntitiesWithinAABB(PlayerEntity.class, new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d),
								z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)), null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf(x, y, z)).findFirst().orElse(null))
								.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new QualityEquipmentModVariables.PlayerVariables())).bowpowerful == true) {
							if (entity instanceof LivingEntity)
								((LivingEntity) entity)
										.setHealth((float) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1)
												- amount * statsjsonobject.get("Powerful Positive Projectile Damage Stat").getAsDouble()));
						} else if ((((Entity) world.getEntitiesWithinAABB(PlayerEntity.class, new AxisAlignedBB(x - (1000 / 2d), y - (1000 / 2d),
								z - (1000 / 2d), x + (1000 / 2d), y + (1000 / 2d), z + (1000 / 2d)), null).stream().sorted(new Object() {
									Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
										return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
									}
								}.compareDistOf(x, y, z)).findFirst().orElse(null))
								.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new QualityEquipmentModVariables.PlayerVariables())).bowlegendary == true) {
							if (entity instanceof LivingEntity)
								((LivingEntity) entity)
										.setHealth((float) (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1)
												- amount * statsjsonobject.get("Legendary Bow Positive Projectile Damage Stat").getAsDouble()));
						}
					}
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
