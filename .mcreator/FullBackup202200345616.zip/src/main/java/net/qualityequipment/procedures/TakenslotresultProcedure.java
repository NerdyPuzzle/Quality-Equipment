package net.qualityequipment.procedures;

import net.qualityequipment.QualityEquipmentModVariables;
import net.qualityequipment.QualityEquipmentMod;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.HoeItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ArmorItem;
import net.minecraft.inventory.container.Slot;
import net.minecraft.inventory.container.Container;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.CommandSource;
import net.minecraft.block.Blocks;

import java.util.function.Supplier;
import java.util.Map;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;

import com.google.gson.Gson;

public class TakenslotresultProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency world for procedure Takenslotresult!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency x for procedure Takenslotresult!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency y for procedure Takenslotresult!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency z for procedure Takenslotresult!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				QualityEquipmentMod.LOGGER.warn("Failed to load dependency entity for procedure Takenslotresult!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		Entity entity = (Entity) dependencies.get("entity");
		boolean repeat = false;
		String material = "";
		File qualityequipment = new File("");
		File chance = new File("");
		File stats = new File("");
		com.google.gson.JsonObject mainjsonobject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject chancejsonobject = new com.google.gson.JsonObject();
		com.google.gson.JsonObject statsjsonobject = new com.google.gson.JsonObject();
		double Worthless = 0;
		double Broken = 0;
		double Chipped = 0;
		double Bulky = 0;
		double Rusted = 0;
		double Clumsy = 0;
		double Shorter = 0;
		double Pokey = 0;
		double Broad = 0;
		double Thin = 0;
		double Vicious = 0;
		double Longer = 0;
		double Sharp = 0;
		double Keen = 0;
		double Graceful = 0;
		double Sweeping = 0;
		double Legendary = 0;
		double ClumsyBow = 0;
		double Cracked = 0;
		double Light = 0;
		double Powerful = 0;
		double LegendaryBow = 0;
		double Crumbling = 0;
		double Dented = 0;
		double Heavy = 0;
		double Thick = 0;
		double Lucky = 0;
		double Springy = 0;
		double Speedy = 0;
		double Tough = 0;
		double Protective = 0;
		double Solid = 0;
		double Masterful = 0;
		double HeavyShield = 0;
		double ThickShield = 0;
		double SolidShield = 0;
		chance = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgechance.json");
		stats = (File) new File((FMLPaths.GAMEDIR.get().toString() + "/config/QualityEquipment/"), File.separator + "reforgestats.json");
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(chance));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				chancejsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				Worthless = chancejsonobject.get("Worthless").getAsDouble();
				Broken = chancejsonobject.get("Broken").getAsDouble();
				Chipped = chancejsonobject.get("Chipped").getAsDouble();
				Bulky = chancejsonobject.get("Bulky").getAsDouble();
				Rusted = chancejsonobject.get("Rusted").getAsDouble();
				Clumsy = chancejsonobject.get("Clumsy").getAsDouble();
				Pokey = chancejsonobject.get("Pokey").getAsDouble();
				Shorter = chancejsonobject.get("Short").getAsDouble();
				Broad = chancejsonobject.get("Broad").getAsDouble();
				Thin = chancejsonobject.get("Thin").getAsDouble();
				Vicious = chancejsonobject.get("Vicious").getAsDouble();
				Longer = chancejsonobject.get("Long").getAsDouble();
				Sharp = chancejsonobject.get("Sharp").getAsDouble();
				Keen = chancejsonobject.get("Keen").getAsDouble();
				Graceful = chancejsonobject.get("Graceful").getAsDouble();
				Sweeping = chancejsonobject.get("Sweeping").getAsDouble();
				Legendary = chancejsonobject.get("Legendary").getAsDouble();
				ClumsyBow = chancejsonobject.get("Clumsy Bow").getAsDouble();
				Cracked = chancejsonobject.get("Cracked").getAsDouble();
				Light = chancejsonobject.get("Light").getAsDouble();
				Powerful = chancejsonobject.get("Powerful").getAsDouble();
				LegendaryBow = chancejsonobject.get("Legendary Bow").getAsDouble();
				Crumbling = chancejsonobject.get("Crumbling").getAsDouble();
				Dented = chancejsonobject.get("Dented").getAsDouble();
				Heavy = chancejsonobject.get("Heavy").getAsDouble();
				Thick = chancejsonobject.get("Thick").getAsDouble();
				Lucky = chancejsonobject.get("Lucky").getAsDouble();
				Springy = chancejsonobject.get("Springy").getAsDouble();
				Speedy = chancejsonobject.get("Speedy").getAsDouble();
				Tough = chancejsonobject.get("Tough").getAsDouble();
				Protective = chancejsonobject.get("Protective").getAsDouble();
				Solid = chancejsonobject.get("Solid").getAsDouble();
				Masterful = chancejsonobject.get("Masterful").getAsDouble();
				HeavyShield = chancejsonobject.get("Heavy Shield").getAsDouble();
				ThickShield = chancejsonobject.get("Thick Shield").getAsDouble();
				SolidShield = chancejsonobject.get("Solid Shield").getAsDouble();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		{
			try {
				BufferedReader bufferedReader = new BufferedReader(new FileReader(stats));
				StringBuilder jsonstringbuilder = new StringBuilder();
				String line;
				while ((line = bufferedReader.readLine()) != null) {
					jsonstringbuilder.append(line);
				}
				bufferedReader.close();
				statsjsonobject = new Gson().fromJson(jsonstringbuilder.toString(), com.google.gson.JsonObject.class);
				if ((new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof SwordItem || (new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof PickaxeItem || (new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof AxeItem || (new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof ShovelItem || (new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof HoeItem) {
					if (world instanceof ServerWorld) {
						((World) world).getServer().getCommandManager().handleCommand(
								new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
										new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
								"data remove block ~ ~ ~ Items[{Slot:0b}].tag.display");
					}
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Worthless", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Broken", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Chipped", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Bulky", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Rusted", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Clumsy", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Short", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Broad", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Thin", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Vicious", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Long", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Sharp", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Keen", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Graceful", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Sweeping", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Legendary", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Pokey", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Reforged", (true));
					repeat = (true);
					while (repeat == true) {
						if (Math.random() <= Worthless) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Worthless", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A74"
												+ "" + statsjsonobject.get("Worthless Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-10% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Worthless Negative Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Worthless Negative Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-1 Reach Distance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Broken) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Broken", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A78"
												+ "" + statsjsonobject.get("Broken Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Broken Negative Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Chipped) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Chipped", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
												+ "" + statsjsonobject.get("Chipped Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Chipped Negative Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Chipped Negative Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Bulky) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Bulky", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A78"
												+ "" + statsjsonobject.get("Bulky Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-15% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Bulky Negative Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Rusted) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Rusted", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
												+ "" + statsjsonobject.get("Rusted Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-10% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Rusted Negative Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Pokey) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Pokey", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
												+ "" + statsjsonobject.get("Pokey Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-10% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Pokey Positive Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Clumsy) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Clumsy", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
												+ "" + statsjsonobject.get("Clumsy Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-5% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Clumsy Negative Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Shorter) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Short", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
												+ "" + statsjsonobject.get("Short Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-1 Reach Distance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Broad) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Broad", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
												+ "" + statsjsonobject.get("Broad Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-5% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Broad Negative Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Broad Positive Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Thin) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Thin", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
												+ "" + statsjsonobject.get("Thin Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Thin Positive Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Thin Negative Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Vicious) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Vicious", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
												+ "" + statsjsonobject.get("Vicious Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Vicious Positive Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-0.5 Reach Distance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Longer) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Long", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Long Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+0.5 Reach Distance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Sharp) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Sharp", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Sharp Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Sharp Positive Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Keen) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Keen", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Keen Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Keen Positive Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Keen Positive Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Graceful) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Graceful", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7b"
												+ "" + statsjsonobject.get("Graceful Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+15% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Graceful Positive Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Sweeping) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Sweeping", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7b"
												+ "" + statsjsonobject.get("Sweeping Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Sweeping Positive Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+0.5 Reach Distance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Legendary) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Legendary", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7d"
												+ "" + statsjsonobject.get("Legendary Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+10% Dig Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Legendary Positive Attack Speed Display").getAsString()
												+ " Attack Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Legendary Positive Attack Damage Display").getAsString()
												+ " Attack Damage\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+0.5 Reach Distance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else {
							repeat = (true);
						}
					}
					{
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									((Slot) ((Map) invobj).get((int) (2))).decrStackSize((int) (1));
									_current.detectAndSendChanges();
								}
							}
						}
					}
					{
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									((Slot) ((Map) invobj).get((int) (1))).decrStackSize((int) (1));
									_current.detectAndSendChanges();
								}
							}
						}
					}
					{
						boolean _setval = (true);
						entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.successhammer2 = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
					new Object() {
						private int ticks = 0;
						private float waitTicks;
						private IWorld world;

						public void start(IWorld world, int waitTicks) {
							this.waitTicks = waitTicks;
							MinecraftForge.EVENT_BUS.register(this);
							this.world = world;
						}

						@SubscribeEvent
						public void tick(TickEvent.ServerTickEvent event) {
							if (event.phase == TickEvent.Phase.END) {
								this.ticks += 1;
								if (this.ticks >= this.waitTicks)
									run();
							}
						}

						private void run() {
							{
								boolean _setval = (false);
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.successhammer2 = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							MinecraftForge.EVENT_BUS.unregister(this);
						}
					}.start(world, (int) 3.5);
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.use")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.use")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
					}
				}
				if (((new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() == Items.BOW || (new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() == Items.CROSSBOW) && (new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (1))).getItem() == Blocks.OAK_LOG.asItem() || (new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof BowItem || (new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof CrossbowItem) {
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.use")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.use")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
					}
					if (world instanceof ServerWorld) {
						((World) world).getServer().getCommandManager().handleCommand(
								new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
										new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
								"data remove block ~ ~ ~ Items[{Slot:0b}].tag.display");
					}
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Clumsy Bow", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Cracked", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Light", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Powerful", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Legendary Bow", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Reforged", (true));
					repeat = (true);
					while (repeat == true) {
						if (Math.random() <= ClumsyBow) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Clumsy Bow", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
												+ "" + statsjsonobject.get("Clumsy Bow Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Clumsy Bow Negative Projectile Damage Display").getAsString()
												+ " Projectile Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Cracked) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Cracked", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A78"
												+ "" + statsjsonobject.get("Cracked Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Cracked Negative Projectile Damage Display").getAsString()
												+ " Projectile Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Light) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Light", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Light Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Light Positive Projectile Damage Display").getAsString()
												+ " Projectile Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Powerful) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Powerful", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7b"
												+ "" + statsjsonobject.get("Powerful Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Powerful Positive Projectile Damage Display").getAsString()
												+ " Projectile Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= LegendaryBow) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Legendary Bow", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7d"
												+ "" + statsjsonobject.get("Legendary Bow Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Main Hand:\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Legendary Bow Positive Projectile Damage Display").getAsString()
												+ " Projectile Damage\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else {
							repeat = (true);
						}
					}
					{
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									((Slot) ((Map) invobj).get((int) (2))).decrStackSize((int) (1));
									_current.detectAndSendChanges();
								}
							}
						}
					}
					{
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									((Slot) ((Map) invobj).get((int) (1))).decrStackSize((int) (1));
									_current.detectAndSendChanges();
								}
							}
						}
					}
					{
						boolean _setval = (true);
						entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.successhammer2 = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
					new Object() {
						private int ticks = 0;
						private float waitTicks;
						private IWorld world;

						public void start(IWorld world, int waitTicks) {
							this.waitTicks = waitTicks;
							MinecraftForge.EVENT_BUS.register(this);
							this.world = world;
						}

						@SubscribeEvent
						public void tick(TickEvent.ServerTickEvent event) {
							if (event.phase == TickEvent.Phase.END) {
								this.ticks += 1;
								if (this.ticks >= this.waitTicks)
									run();
							}
						}

						private void run() {
							{
								boolean _setval = (false);
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.successhammer2 = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							MinecraftForge.EVENT_BUS.unregister(this);
						}
					}.start(world, (int) 3.5);
				}
				if ((new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof ArmorItem) {
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.use")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.use")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
					}
					if (world instanceof ServerWorld) {
						((World) world).getServer().getCommandManager().handleCommand(
								new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
										new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
								"data remove block ~ ~ ~ Items[{Slot:0b}].tag.display");
					}
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Crumbling", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Dented", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Heavy", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Thick", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Lucky", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Springy", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Speedy", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Tough", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Protective", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Solid", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Masterful", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Reforged", (true));
					repeat = (true);
					while (repeat == true) {
						if (Math.random() <= Crumbling) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Crumbling", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
												+ "" + statsjsonobject.get("Crumbling Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
												+ statsjsonobject.get("Crumbling Negative Armor Toughness Display").getAsString()
												+ " Armor Toughness\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A7c-"
												+ statsjsonobject.get("Crumbling Negative Armor Display").getAsString()
												+ " Armor\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Dented) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Dented", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A78"
												+ "" + statsjsonobject.get("Dented Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
												+ statsjsonobject.get("Dented Negative Armor Display").getAsString()
												+ " Armor\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Heavy) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Heavy", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
												+ "" + statsjsonobject.get("Heavy Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
												+ statsjsonobject.get("Heavy Negative Speed Display").getAsString()
												+ " Speed\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Thick) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Thick", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
												+ "" + statsjsonobject.get("Thick Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
												+ statsjsonobject.get("Thick Negative Speed Display").getAsString()
												+ " Speed\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Thick Positive Armor Display").getAsString()
												+ " Armor\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Lucky) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Lucky", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7b"
												+ "" + statsjsonobject.get("Lucky Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A79 \u00A79+"
												+ statsjsonobject.get("Lucky Positive Luck Display").getAsString()
												+ " Luck\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Springy) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Springy", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Springy Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+0.5 Jump Height\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Speedy) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Speedy", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Speedy Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Speedy Positive Speed Display").getAsString()
												+ " Speed\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Tough) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Tough", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Tough Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Tough Positive Armor Toughness Display").getAsString()
												+ " Armor Toughness\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Protective) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Protective", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Protective Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Protective Positive Armor Display").getAsString()
												+ " Armor\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Solid) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Solid", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Solid Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Solid Positive Knockback Resistance Display").getAsString()
												+ " Knockback Resistance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= Masterful) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Masterful", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7d"
												+ "" + statsjsonobject.get("Masterful Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77While Worn:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Masterful Positive Armor Toughness Display").getAsString()
												+ " Armor Toughness\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Masterful Positive Armor Display").getAsString()
												+ " Armor\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Masterful Positive Knockback Resistance Display").getAsString()
												+ " Knockback Resistance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else {
							repeat = (true);
						}
					}
					{
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									((Slot) ((Map) invobj).get((int) (2))).decrStackSize((int) (1));
									_current.detectAndSendChanges();
								}
							}
						}
					}
					{
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									((Slot) ((Map) invobj).get((int) (1))).decrStackSize((int) (1));
									_current.detectAndSendChanges();
								}
							}
						}
					}
					{
						boolean _setval = (true);
						entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.successhammer2 = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
					new Object() {
						private int ticks = 0;
						private float waitTicks;
						private IWorld world;

						public void start(IWorld world, int waitTicks) {
							this.waitTicks = waitTicks;
							MinecraftForge.EVENT_BUS.register(this);
							this.world = world;
						}

						@SubscribeEvent
						public void tick(TickEvent.ServerTickEvent event) {
							if (event.phase == TickEvent.Phase.END) {
								this.ticks += 1;
								if (this.ticks >= this.waitTicks)
									run();
							}
						}

						private void run() {
							{
								boolean _setval = (false);
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.successhammer2 = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							MinecraftForge.EVENT_BUS.unregister(this);
						}
					}.start(world, (int) 3.5);
				}
				if ((new Object() {
					public ItemStack getItemStack(int sltid) {
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									return ((Slot) ((Map) invobj).get(sltid)).getStack();
								}
							}
						}
						return ItemStack.EMPTY;
					}
				}.getItemStack((int) (0))).getItem() instanceof ShieldItem) {
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.use")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.anvil.use")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
					}
					if (world instanceof ServerWorld) {
						((World) world).getServer().getCommandManager().handleCommand(
								new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
										new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
								"data remove block ~ ~ ~ Items[{Slot:0b}].tag.display");
					}
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Heavy Shield", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Thick Shield", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Solid Shield", (false));
					(new Object() {
						public ItemStack getItemStack(int sltid) {
							Entity _ent = entity;
							if (_ent instanceof ServerPlayerEntity) {
								Container _current = ((ServerPlayerEntity) _ent).openContainer;
								if (_current instanceof Supplier) {
									Object invobj = ((Supplier) _current).get();
									if (invobj instanceof Map) {
										return ((Slot) ((Map) invobj).get(sltid)).getStack();
									}
								}
							}
							return ItemStack.EMPTY;
						}
					}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Reforged", (true));
					repeat = (true);
					while (repeat == true) {
						if (Math.random() <= HeavyShield) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Heavy Shield", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7c"
												+ "" + statsjsonobject.get("Heavy Shield Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
												+ statsjsonobject.get("Heavy Shield Negative Speed Display").getAsString()
												+ " Speed\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= ThickShield) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Thick Shield", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A7e"
												+ "" + statsjsonobject.get("Thick Shield Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A7c-"
												+ statsjsonobject.get("Thick Shield Negative Speed Display").getAsString()
												+ " Speed\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Thick Shield Positive Armor Display").getAsString()
												+ " Armor\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else if (Math.random() <= SolidShield) {
							(new Object() {
								public ItemStack getItemStack(int sltid) {
									Entity _ent = entity;
									if (_ent instanceof ServerPlayerEntity) {
										Container _current = ((ServerPlayerEntity) _ent).openContainer;
										if (_current instanceof Supplier) {
											Object invobj = ((Supplier) _current).get();
											if (invobj instanceof Map) {
												return ((Slot) ((Map) invobj).get(sltid)).getStack();
											}
										}
									}
									return ItemStack.EMPTY;
								}
							}.getItemStack((int) (0))).getOrCreateTag().putBoolean("Solid Shield", (true));
							if (world instanceof ServerWorld) {
								((World) world).getServer().getCommandManager().handleCommand(
										new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
												new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
										("data modify block ~ ~ ~ Items[{Slot:0b}].tag.display set value {Lore:['[{\"text\":\"\u00A79 \",\"italic\":false}]','[{\"text\":\"\u00A77Quality: \u00A79"
												+ "" + statsjsonobject.get("Solid Shield Name").getAsString()
												+ "\",\"italic\":false}]','[{\"text\":\"\u00A77When in Off Hand:\",\"italic\":false}]','[{\"text\":\"\u00A7c \u00A79+"
												+ statsjsonobject.get("Solid Shield Positive Knockback Resistance Display").getAsString()
												+ " Knockback Resistance\",\"italic\":false}]']}"));
							}
							repeat = (false);
						} else {
							repeat = (true);
						}
					}
					{
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									((Slot) ((Map) invobj).get((int) (2))).decrStackSize((int) (1));
									_current.detectAndSendChanges();
								}
							}
						}
					}
					{
						Entity _ent = entity;
						if (_ent instanceof ServerPlayerEntity) {
							Container _current = ((ServerPlayerEntity) _ent).openContainer;
							if (_current instanceof Supplier) {
								Object invobj = ((Supplier) _current).get();
								if (invobj instanceof Map) {
									((Slot) ((Map) invobj).get((int) (1))).decrStackSize((int) (1));
									_current.detectAndSendChanges();
								}
							}
						}
					}
					{
						boolean _setval = (true);
						entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.successhammer2 = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
					new Object() {
						private int ticks = 0;
						private float waitTicks;
						private IWorld world;

						public void start(IWorld world, int waitTicks) {
							this.waitTicks = waitTicks;
							MinecraftForge.EVENT_BUS.register(this);
							this.world = world;
						}

						@SubscribeEvent
						public void tick(TickEvent.ServerTickEvent event) {
							if (event.phase == TickEvent.Phase.END) {
								this.ticks += 1;
								if (this.ticks >= this.waitTicks)
									run();
							}
						}

						private void run() {
							{
								boolean _setval = (false);
								entity.getCapability(QualityEquipmentModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
									capability.successhammer2 = _setval;
									capability.syncPlayerVariables(entity);
								});
							}
							MinecraftForge.EVENT_BUS.unregister(this);
						}
					}.start(world, (int) 3.5);
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
