package net.qualityequipment.procedures;

import net.qualityequipment.configuration.ReforgesConfiguration;

import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.TieredItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import javax.annotation.Nullable;

import java.util.concurrent.atomic.AtomicReference;

@Mod.EventBusSubscriber
public class AutoReforgeProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level(), event.player);
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		boolean reforge = false;
		double randomr = 0;
		if (ReforgesConfiguration.AUTO_REFORGE.get()) {
			if (!world.isClientSide()) {
				{
					AtomicReference<IItemHandler> _iitemhandlerref = new AtomicReference<>();
					entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(_iitemhandlerref::set);
					if (_iitemhandlerref.get() != null) {
						for (int _idx = 0; _idx < _iitemhandlerref.get().getSlots(); _idx++) {
							ItemStack itemstackiterator = _iitemhandlerref.get().getStackInSlot(_idx);
							if (itemstackiterator.getItem() instanceof TieredItem || itemstackiterator.getItem() instanceof BowItem || itemstackiterator.getItem() instanceof CrossbowItem || itemstackiterator.getItem() instanceof ShieldItem
									|| itemstackiterator.getItem() instanceof ArmorItem) {
								if (!itemstackiterator.hasTag()) {
									reforge = true;
								}
								if (itemstackiterator.hasTag()) {
									if (!itemstackiterator.getTag().contains("Autoreforge")) {
										reforge = true;
									}
								}
							}
							if (reforge) {
								itemstackiterator.getOrCreateTag().putBoolean("Autoreforge", true);
								if ((double) ReforgesConfiguration.AUTO_REFORGE_CHANCE.get() >= Math.random()) {
									if (itemstackiterator.getItem() instanceof TieredItem) {
										randomr = Mth.nextInt(RandomSource.create(), 1, 17);
										if (randomr == 1) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.worthless");
										} else if (randomr == 2) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.broken");
										} else if (randomr == 3) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.chipped");
										} else if (randomr == 4) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.bulky");
										} else if (randomr == 5) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.rusted");
										} else if (randomr == 6) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.clumsy");
										} else if (randomr == 7) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.short");
										} else if (randomr == 8) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.broad");
										} else if (randomr == 9) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.thin");
										} else if (randomr == 10) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.vicious");
										} else if (randomr == 11) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.long");
										} else if (randomr == 12) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.sharp");
										} else if (randomr == 13) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.keen");
										} else if (randomr == 14) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.graceful");
										} else if (randomr == 15) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.sweeping");
										} else if (randomr == 16) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.legendary");
										} else if (randomr == 17) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.pokey");
										}
									} else if (itemstackiterator.getItem() instanceof BowItem || itemstackiterator.getItem() instanceof CrossbowItem) {
										randomr = Mth.nextInt(RandomSource.create(), 1, 5);
										if (randomr == 1) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.clumsy");
										} else if (randomr == 2) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.cracked");
										} else if (randomr == 3) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.light");
										} else if (randomr == 4) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.powerful");
										} else if (randomr == 5) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.legendary");
										}
									} else if (itemstackiterator.getItem() instanceof ShieldItem) {
										randomr = Mth.nextInt(RandomSource.create(), 1, 3);
										if (randomr == 1) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.heavy");
										} else if (randomr == 2) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.thick");
										} else if (randomr == 3) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.solid");
										}
									} else if (itemstackiterator.getItem() instanceof ArmorItem) {
										randomr = Mth.nextInt(RandomSource.create(), 1, 12);
										if (randomr == 1) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.crumbling");
										} else if (randomr == 2) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.dented");
										} else if (randomr == 3) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.heavy");
										} else if (randomr == 4) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.thick");
										} else if (randomr == 5) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.lucky");
										} else if (randomr == 6) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.tall");
										} else if (randomr == 7) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.speedy");
										} else if (randomr == 8) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.tough");
										} else if (randomr == 9) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.protective");
										} else if (randomr == 10) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.solid");
										} else if (randomr == 11) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.masterful");
										} else if (randomr == 12) {
											itemstackiterator.getOrCreateTag().putString("Reforge", "quality_equipment.quality.cumbersome");
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
