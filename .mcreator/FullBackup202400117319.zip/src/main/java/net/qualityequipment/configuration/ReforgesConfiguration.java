package net.qualityequipment.configuration;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.common.ForgeConfigSpec;

import net.minecraft.world.level.block.Blocks;

import java.util.List;

public class ReforgesConfiguration {
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.ConfigValue<String> FALLBACK_MATERIAL;
	public static final ForgeConfigSpec.ConfigValue<List<? extends String>> MATERIAL_OVERRIDES;
	public static final ForgeConfigSpec.ConfigValue<List<? extends String>> REFORGE_BLACKLIST;
	public static final ForgeConfigSpec.ConfigValue<Boolean> AUTO_REFORGE;
	public static final ForgeConfigSpec.ConfigValue<Double> AUTO_REFORGE_CHANCE;
	public static final ForgeConfigSpec.ConfigValue<List<? extends String>> QUALITIES;
	static {
		BUILDER.push("Materials");
		FALLBACK_MATERIAL = BUILDER.comment("This material will be used to reforge an item that does not have a material override or repair item").define("Fallback", ForgeRegistries.ITEMS.getKey(Blocks.OBSIDIAN.asItem()).toString());
		MATERIAL_OVERRIDES = BUILDER.comment(
				"In this list you can define different reforge items for specific equipment.\nThis can override repair items and will be used instead of the fallback item in case no repair item exists.\nThe left item is the equipment and right is the material.")
				.defineList("Overrides", List.of("minecraft:bow,minecraft:string", "minecraft:crossbow,minecraft:iron_ingot"), entry -> true);
		BUILDER.pop();
		BUILDER.push("Reforging");
		REFORGE_BLACKLIST = BUILDER.comment("A list of equipment that cannot be reforged.").defineList("Blacklist", List.of(), entry -> true);
		AUTO_REFORGE = BUILDER.comment("If true, items have a chance to be automatically reforged when they enter the player's inventory.").define("AutoReforge", true);
		AUTO_REFORGE_CHANCE = BUILDER.comment("The chance an item has of being automatically reforged.\nMax is 1 (100%) and minimum is 0.1 (10%).").define("AutoReforgeChance", 0.5);
		BUILDER.pop();
		BUILDER.push("Qualities");
		QUALITIES = BUILDER.comment("A list of json objects assigned to a translation key.\nEach json object represents a quality.\nNew qualities can be freely added so long as their format is valid.").defineList("QualityList", List.of(
				"quality_equipment.quality.worthless={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":-0.1},{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":-0.1},{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":-0.1},{\"uuid\":\"bdb8f2c3-dd0a-44cb-b82e-cbcbbea0171d\",\"attribute\":\"forge:entity_reach\",\"operation\":\"addition\",\"value\":-0.1}]}",
				"quality_equipment.quality.broken={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":-0.15}]}",
				"quality_equipment.quality.chipped={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":-0.05},{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":-0.05}]}",
				"quality_equipment.quality.bulky={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":-0.15},{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":-0.15}]}",
				"quality_equipment.quality.rusted={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":-0.1},{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":-0.1}]}",
				"quality_equipment.quality.clumsy={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":-0.05},{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":-0.05}]}",
				"quality_equipment.quality.clumsy={\"type\":\"bow\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:projectile_damage\",\"operation\":\"multiply_base\",\"value\":-0.05}]}",
				"quality_equipment.quality.short={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"bdb8f2c3-dd0a-44cb-b82e-cbcbbea0171d\",\"attribute\":\"forge:entity_reach\",\"operation\":\"addition\",\"value\":-1}]}",
				"quality_equipment.quality.broad={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":-0.05},{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":-0.05},{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":0.1}]}",
				"quality_equipment.quality.thin={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":0.1},{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":-0.05}]}",
				"quality_equipment.quality.vicious={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":0.15},{\"uuid\":\"bdb8f2c3-dd0a-44cb-b82e-cbcbbea0171d\",\"attribute\":\"forge:entity_reach\",\"operation\":\"addition\",\"value\":-0.5}]}",
				"quality_equipment.quality.long={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"bdb8f2c3-dd0a-44cb-b82e-cbcbbea0171d\",\"attribute\":\"forge:entity_reach\",\"operation\":\"addition\",\"value\":0.5}]}",
				"quality_equipment.quality.sharp={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":0.1}]}",
				"quality_equipment.quality.keen={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":0.1},{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":0.1}]}",
				"quality_equipment.quality.graceful={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":0.15},{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":0.15}]}",
				"quality_equipment.quality.sweeping={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":0.2},{\"uuid\":\"bdb8f2c3-dd0a-44cb-b82e-cbcbbea0171d\",\"attribute\":\"forge:entity_reach\",\"operation\":\"addition\",\"value\":0.5}]}",
				"quality_equipment.quality.legendary={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":0.1},{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":0.1},{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":0.15},{\"uuid\":\"bdb8f2c3-dd0a-44cb-b82e-cbcbbea0171d\",\"attribute\":\"forge:entity_reach\",\"operation\":\"addition\",\"value\":0.5}]}",
				"quality_equipment.quality.legendary={\"type\":\"bow\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:projectile_damage\",\"operation\":\"multiply_base\",\"value\":0.15}]}",
				"quality_equipment.quality.pokey={\"type\":\"tool\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":-0.1},{\"uuid\":\"c1127ef0-9c11-48e0-98da-faa1fcc010b3\",\"attribute\":\"minecraft:generic.attack_damage\",\"operation\":\"multiply_total\",\"value\":0.05}]}",
				"quality_equipment.quality.cracked={\"type\":\"bow\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:projectile_damage\",\"operation\":\"multiply_base\",\"value\":-0.15}]}",
				"quality_equipment.quality.light={\"type\":\"bow\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:projectile_damage\",\"operation\":\"multiply_base\",\"value\":0.05}]}",
				"quality_equipment.quality.powerful={\"type\":\"bow\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:projectile_damage\",\"operation\":\"multiply_base\",\"value\":0.1}]}",
				"quality_equipment.quality.crumbling={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"111d0fd9-8579-4da1-ab4b-7afdd43477ca\",\"attribute\":\"minecraft:generic.armor_toughness\",\"operation\":\"addition\",\"value\":-1},{\"uuid\":\"4b96c6e4-beef-48ad-969a-ee4387157313\",\"attribute\":\"minecraft:generic.armor\",\"operation\":\"addition\",\"value\":-1.5}]}",
				"quality_equipment.quality.dented={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"4b96c6e4-beef-48ad-969a-ee4387157313\",\"attribute\":\"minecraft:generic.armor\",\"operation\":\"addition\",\"value\":-1}]}",
				"quality_equipment.quality.heavy={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"366a1b03-95a7-45b7-8527-a8035de51844\",\"attribute\":\"minecraft:generic.movement_speed\",\"operation\":\"multiply_total\",\"value\":-0.1}]}",
				"quality_equipment.quality.heavy={\"type\":\"shield\",\"modifiers\":[{\"uuid\":\"366a1b03-95a7-45b7-8527-a8035de51844\",\"attribute\":\"minecraft:generic.movement_speed\",\"operation\":\"multiply_total\",\"value\":-0.1}]}",
				"quality_equipment.quality.thick={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"366a1b03-95a7-45b7-8527-a8035de51844\",\"attribute\":\"minecraft:generic.movement_speed\",\"operation\":\"multiply_total\",\"value\":-0.05},{\"uuid\":\"4b96c6e4-beef-48ad-969a-ee4387157313\",\"attribute\":\"minecraft:generic.armor\",\"operation\":\"addition\",\"value\":0.5}]}",
				"quality_equipment.quality.thick={\"type\":\"shield\",\"modifiers\":[{\"uuid\":\"366a1b03-95a7-45b7-8527-a8035de51844\",\"attribute\":\"minecraft:generic.movement_speed\",\"operation\":\"multiply_total\",\"value\":-0.05},{\"uuid\":\"4b96c6e4-beef-48ad-969a-ee4387157313\",\"attribute\":\"minecraft:generic.armor\",\"operation\":\"addition\",\"value\":0.5}]}",
				"quality_equipment.quality.lucky={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"a6c92712-63aa-441f-9248-4d40ca2f2c33\",\"attribute\":\"minecraft:generic.luck\",\"operation\":\"addition\",\"value\":0.5}]}",
				"quality_equipment.quality.tall={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"85779448-0d6d-44b4-aa52-ab569c8c9ff5\",\"attribute\":\"forge:step_height_addition\",\"operation\":\"addition\",\"value\":1.5}]}",
				"quality_equipment.quality.speedy={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"366a1b03-95a7-45b7-8527-a8035de51844\",\"attribute\":\"minecraft:generic.movement_speed\",\"operation\":\"multiply_total\",\"value\":0.1}]}",
				"quality_equipment.quality.tough={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"111d0fd9-8579-4da1-ab4b-7afdd43477ca\",\"attribute\":\"minecraft:generic.armor_toughness\",\"operation\":\"addition\",\"value\":1}]}",
				"quality_equipment.quality.protective={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"4b96c6e4-beef-48ad-969a-ee4387157313\",\"attribute\":\"minecraft:generic.armor\",\"operation\":\"addition\",\"value\":0.5}]}",
				"quality_equipment.quality.solid={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"96595416-05d1-4ddc-9560-c8cf5ae70b48\",\"attribute\":\"minecraft:generic.knockback_resistance\",\"operation\":\"addition\",\"value\":0.05}]}",
				"quality_equipment.quality.solid={\"type\":\"shield\",\"modifiers\":[{\"uuid\":\"96595416-05d1-4ddc-9560-c8cf5ae70b48\",\"attribute\":\"minecraft:generic.knockback_resistance\",\"operation\":\"addition\",\"value\":0.05}]}",
				"quality_equipment.quality.masterful={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"111d0fd9-8579-4da1-ab4b-7afdd43477ca\",\"attribute\":\"minecraft:generic.armor_toughness\",\"operation\":\"addition\",\"value\":1},{\"uuid\":\"4b96c6e4-beef-48ad-969a-ee4387157313\",\"attribute\":\"minecraft:generic.armor\",\"operation\":\"addition\",\"value\":0.5},{\"uuid\":\"96595416-05d1-4ddc-9560-c8cf5ae70b48\",\"attribute\":\"minecraft:generic.knockback_resistance\",\"operation\":\"addition\",\"value\":0.05}]}",
				"quality_equipment.quality.cumbersome={\"type\":\"armor\",\"modifiers\":[{\"uuid\":\"5e86f314-00dd-4b50-97dd-7cc5d2fdd360\",\"attribute\":\"quality_equipment:dig_speed\",\"operation\":\"multiply_base\",\"value\":-0.1},{\"uuid\":\"3d9461b2-3aed-4732-8760-4ebc2ea56a05\",\"attribute\":\"minecraft:generic.attack_speed\",\"operation\":\"multiply_total\",\"value\":-0.1}]}"),
				entry -> true);
		BUILDER.pop();
		SPEC = BUILDER.build();
	}
}
